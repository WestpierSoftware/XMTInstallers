@echo off
setlocal
cd /d "%~dp0"

REM ------------------------------------------------------------
REM XmtFileLink Live-State Checker v2
REM READ-ONLY
REM ------------------------------------------------------------

set "SERVICE_NAME=XmtFileLinkService"

REM Optional: fill these in before running if you know the exact paths.
REM Example:
REM set "INPUT_DIR=E:\SomeFolder\Incoming"
REM set "LOG_PATH=E:\SomeFolder\logs\XMTFileLink.log"

set "INPUT_DIR="
set "LOG_PATH="

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "Get-ChildItem -LiteralPath '%~dp0' -Filter *.ps1 -File | Unblock-File -ErrorAction SilentlyContinue; & '%~dp0XmtFileLink_Live_State_Checker_v2.ps1' -ServiceName '%SERVICE_NAME%' -InputDir '%INPUT_DIR%' -LogPath '%LOG_PATH%'"

echo.
echo Finished. Check the new Output_YYYYMMDD_HHMMSS folder.
echo.
pause
