﻿param(
    [string]$ServiceName = "XmtFileLinkService",
    [string]$InputDir = "",
    [string]$LogPath = ""
)

$ErrorActionPreference = "Continue"
$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$outDir = Join-Path $PSScriptRoot ("Output_" + $ts)
New-Item -ItemType Directory -Path $outDir -Force | Out-Null
$outFile = Join-Path $outDir "XmtFileLink_Live_State_Report.txt"

function Add-Section([string]$Title) {
    Add-Content -Path $outFile -Value ""
    Add-Content -Path $outFile -Value ("=" * 90)
    Add-Content -Path $outFile -Value $Title
    Add-Content -Path $outFile -Value ("=" * 90)
}

function Add-Obj($obj) {
    if ($null -eq $obj) {
        Add-Content -Path $outFile -Value "<none>"
    } else {
        $obj | Out-String -Width 300 | Add-Content -Path $outFile
    }
}

"XmtFileLink Live-State Checker v2" | Set-Content $outFile
("Collected: " + (Get-Date -Format "yyyy-MM-dd HH:mm:ss zzz")) | Add-Content $outFile
("Computer:  " + $env:COMPUTERNAME) | Add-Content $outFile
("User:      " + [System.Security.Principal.WindowsIdentity]::GetCurrent().Name) | Add-Content $outFile
("Read-only: YES") | Add-Content $outFile

Add-Section "1. SERVICE CONTROL MANAGER - SC QUERYEX"
try {
    (& sc.exe queryex $ServiceName 2>&1) | Add-Content $outFile
} catch {
    Add-Content $outFile $_
}

Add-Section "2. SERVICE CONFIGURATION - SC QC"
try {
    (& sc.exe qc $ServiceName 2>&1) | Add-Content $outFile
} catch {
    Add-Content $outFile $_
}

Add-Section "3. WIN32_SERVICE DETAILS"
$svc = $null
try {
    $svc = Get-CimInstance Win32_Service -Filter "Name='$ServiceName'" -ErrorAction Stop
    Add-Obj ($svc | Select-Object Name,DisplayName,State,Status,Started,StartMode,ProcessId,PathName,StartName,ExitCode,ServiceSpecificExitCode)
} catch {
    Add-Content $outFile ("ERROR: " + $_.Exception.Message)
}

$pidNow = 0
if ($svc -and $svc.ProcessId) { $pidNow = [int]$svc.ProcessId }

Add-Section "4. SERVICE PROCESS DETAILS"
if ($pidNow -gt 0) {
    try {
        $p = Get-CimInstance Win32_Process -Filter "ProcessId=$pidNow" -ErrorAction Stop
        Add-Obj ($p | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate)
        try {
            $gp = Get-Process -Id $pidNow -ErrorAction Stop
            Add-Obj ($gp | Select-Object Id,ProcessName,StartTime,CPU,Responding,Threads,Handles,Path)
        } catch {
            Add-Content $outFile ("Get-Process detail error: " + $_.Exception.Message)
        }
    } catch {
        Add-Content $outFile ("ERROR: " + $_.Exception.Message)
    }
} else {
    Add-Content $outFile "Service PID is 0 / service process not currently attached."
}

Add-Section "5. ALL FILELINK-LIKE PROCESSES"
try {
    $procs = Get-CimInstance Win32_Process | Where-Object {
        ($_.Name -match '(?i)filelink') -or
        ($_.ExecutablePath -match '(?i)filelink') -or
        ($_.CommandLine -match '(?i)filelink')
    } | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate
    Add-Obj $procs
} catch {
    Add-Content $outFile ("ERROR: " + $_.Exception.Message)
}

Add-Section "6. TCP CONNECTIONS OWNED BY FILELINK PID"
if ($pidNow -gt 0) {
    try {
        $tcp = Get-NetTCPConnection -OwningProcess $pidNow -ErrorAction Stop |
            Select-Object State,LocalAddress,LocalPort,RemoteAddress,RemotePort,OwningProcess
        Add-Obj $tcp
    } catch {
        Add-Content $outFile ("No TCP data or insufficient permissions: " + $_.Exception.Message)
    }
} else {
    Add-Content $outFile "<not applicable>"
}

Add-Section "7. HANDLE / THREAD SNAPSHOT"
if ($pidNow -gt 0) {
    try {
        $gp = Get-Process -Id $pidNow -ErrorAction Stop
        Add-Content $outFile ("Handles: " + $gp.Handles)
        Add-Content $outFile ("Threads: " + $gp.Threads.Count)
        $gp.Threads | Select-Object Id,ThreadState,WaitReason,StartTime,TotalProcessorTime |
            Format-Table -AutoSize | Out-String -Width 300 | Add-Content $outFile
    } catch {
        Add-Content $outFile ("ERROR: " + $_.Exception.Message)
    }
} else {
    Add-Content $outFile "<not applicable>"
}

Add-Section "8. RECENT SERVICE CONTROL MANAGER EVENTS"
try {
    $events = Get-WinEvent -FilterHashtable @{
        LogName='System'
        ProviderName='Service Control Manager'
        StartTime=(Get-Date).AddHours(-12)
    } -ErrorAction Stop | Where-Object {
        $_.Message -match [regex]::Escape($ServiceName) -or
        $_.Message -match '(?i)XMT FileLink|FileLink'
    } | Select-Object TimeCreated,Id,LevelDisplayName,Message
    Add-Obj $events
} catch {
    Add-Content $outFile ("ERROR: " + $_.Exception.Message)
}

Add-Section "9. RECENT APPLICATION EVENTS RELATED TO FILELINK / .NET"
try {
    $events = Get-WinEvent -FilterHashtable @{
        LogName='Application'
        StartTime=(Get-Date).AddHours(-12)
    } -ErrorAction Stop | Where-Object {
        $_.ProviderName -match '(?i)\.NET Runtime|Application Error|Windows Error Reporting|FileLink' -or
        $_.Message -match '(?i)filelink|XMTFileLink'
    } | Select-Object TimeCreated,ProviderName,Id,LevelDisplayName,Message
    Add-Obj $events
} catch {
    Add-Content $outFile ("ERROR: " + $_.Exception.Message)
}

Add-Section "10. SERVICE EXECUTABLE FILE METADATA"
if ($svc -and $svc.PathName) {
    $rawPath = $svc.PathName.Trim()
    $exePath = $rawPath
    if ($exePath.StartsWith('"')) {
        $exePath = ($exePath -split '"')[1]
    } elseif ($exePath -match '^(.*?\.exe)\b') {
        $exePath = $matches[1]
    }
    Add-Content $outFile ("Configured PathName: " + $rawPath)
    Add-Content $outFile ("Parsed executable:  " + $exePath)
    if (Test-Path $exePath) {
        $fi = Get-Item $exePath
        Add-Obj ($fi | Select-Object FullName,Length,CreationTime,LastWriteTime,VersionInfo)
    } else {
        Add-Content $outFile "Executable path does not exist."
    }
} else {
    Add-Content $outFile "<service path unavailable>"
}

Add-Section "11. INPUT DIRECTORY SNAPSHOT"
if ([string]::IsNullOrWhiteSpace($InputDir)) {
    Add-Content $outFile "InputDir not supplied. Edit RUN_CHECK_AS_ADMIN.cmd and set INPUT_DIR if desired."
} elseif (-not (Test-Path $InputDir)) {
    Add-Content $outFile ("InputDir not found: " + $InputDir)
} else {
    Add-Content $outFile ("InputDir: " + $InputDir)
    $res = Get-ChildItem -LiteralPath $InputDir -Filter *.RES -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime |
        Select-Object Name,Length,CreationTime,LastWriteTime,FullName
    Add-Content $outFile ("RES count: " + @($res).Count)
    Add-Obj $res
}

Add-Section "12. FILELINK LOG SNAPSHOT"
if ([string]::IsNullOrWhiteSpace($LogPath)) {
    Add-Content $outFile "LogPath not supplied. Edit RUN_CHECK_AS_ADMIN.cmd and set LOG_PATH if desired."
} elseif (-not (Test-Path $LogPath)) {
    Add-Content $outFile ("LogPath not found: " + $LogPath)
} else {
    $lf = Get-Item $LogPath
    Add-Obj ($lf | Select-Object FullName,Length,CreationTime,LastWriteTime)
    Add-Content $outFile ""
    Add-Content $outFile "--- Tail of FileLink log (last 120 lines) ---"
    try {
        Get-Content -LiteralPath $LogPath -Tail 120 -ErrorAction Stop | Add-Content $outFile
    } catch {
        Add-Content $outFile ("ERROR reading log: " + $_.Exception.Message)
    }
}

Add-Section "13. OTHER RECENT FILELINK-NAMED LOG/TEXT FILES NEAR EXECUTABLE"
if ($svc -and $svc.PathName) {
    try {
        $rawPath = $svc.PathName.Trim()
        $exePath = $rawPath
        if ($exePath.StartsWith('"')) {
            $exePath = ($exePath -split '"')[1]
        } elseif ($exePath -match '^(.*?\.exe)\b') {
            $exePath = $matches[1]
        }
        $exeDir = Split-Path $exePath -Parent
        Add-Content $outFile ("Executable directory: " + $exeDir)
        $near = Get-ChildItem -LiteralPath $exeDir -File -Recurse -ErrorAction SilentlyContinue |
            Where-Object {
                $_.Name -match '(?i)filelink|\.log$|\.txt$' -and
                $_.LastWriteTime -gt (Get-Date).AddDays(-2)
            } |
            Sort-Object LastWriteTime -Descending |
            Select-Object -First 100 FullName,Length,LastWriteTime
        Add-Obj $near
    } catch {
        Add-Content $outFile ("ERROR: " + $_.Exception.Message)
    }
} else {
    Add-Content $outFile "<service path unavailable>"
}

Add-Section "14. PROCESS MODULES (BEST EFFORT)"
if ($pidNow -gt 0) {
    try {
        $gp = Get-Process -Id $pidNow -ErrorAction Stop
        $mods = $gp.Modules | Select-Object ModuleName,FileName,FileVersionInfo
        Add-Obj $mods
    } catch {
        Add-Content $outFile ("Unable to enumerate modules: " + $_.Exception.Message)
    }
} else {
    Add-Content $outFile "<not applicable>"
}

Add-Section "15. QUICK INTERPRETATION"
if (-not $svc) {
    Add-Content $outFile "Service not found."
} elseif ($svc.State -ne "Running") {
    Add-Content $outFile ("Service state is " + $svc.State + ", not Running.")
} elseif ($pidNow -le 0) {
    Add-Content $outFile "SCM reports Running but ProcessId is 0. This is abnormal and needs attention."
} else {
    Add-Content $outFile ("SCM reports Running with PID " + $pidNow + ".")
    Add-Content $outFile "If .RES files are accumulating while this PID remains alive and there is no current log activity, focus on:"
    Add-Content $outFile " - worker thread not entering/continuing its polling loop"
    Add-Content $outFile " - waiting on filesystem, database, mutex, event, or another internal resource"
    Add-Content $outFile " - logging path/config mismatch"
    Add-Content $outFile " - duplicate/stale FileLink process"
}

Add-Section "16. IMPORTANT"
Add-Content $outFile "This checker is read-only. It does NOT stop/start services, kill processes, move files, touch SQL data, or modify configuration."
Add-Content $outFile ("Report folder: " + $outDir)

Write-Host ""
Write-Host "DONE."
Write-Host ("Report: " + $outFile)
Write-Host ""
