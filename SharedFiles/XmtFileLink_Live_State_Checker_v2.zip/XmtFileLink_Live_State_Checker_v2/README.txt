XmtFileLink Live-State Checker v2
=================================

PURPOSE
-------
A completely READ-ONLY diagnostic package for the case where Windows reports
XmtFileLinkService as RUNNING, but .RES files accumulate and FileLink writes
nothing to its normal log.

RUN ONLY
--------
RUN_CHECK_AS_ADMIN.cmd

Do not run any other file directly unless troubleshooting the checker itself.

WHAT IT CAPTURES
----------------
1. sc queryex service state and PID
2. sc qc service configuration
3. Win32_Service details
4. current process/executable/command line/start time
5. all FileLink-like processes, to expose duplicates/stale instances
6. TCP connections owned by FileLink PID
7. handle/thread snapshot
8. recent Service Control Manager events
9. recent Application/.NET/FileLink events
10. executable file/version/timestamps
11. optional input directory .RES snapshot
12. optional current FileLink log metadata and last 120 lines
13. recent FileLink/log/text files near the executable
14. loaded modules, where Windows permissions allow
15. quick interpretation

OPTIONAL PATHS
--------------
The checker does not guess your active FileLink input or log path.

If you know them, edit only these two lines in RUN_CHECK_AS_ADMIN.cmd:

    set "INPUT_DIR="
    set "LOG_PATH="

For example:

    set "INPUT_DIR=E:\XMT\FileLink\Incoming"
    set "LOG_PATH=E:\XMT\FileLink\logs\XMTFileLink.log"

If left blank, all service/process/event diagnostics still run.

SAFETY
------
This package:
- does NOT stop/start/restart any service
- does NOT kill any process
- does NOT move/delete/rename .RES files
- does NOT write to SQL Server
- does NOT modify FileLink configuration
- does NOT modify Windows service configuration

It only reads state and writes its own report under the toolkit folder.

CURRENT TEST STATE
------------------
Best diagnostic state is:
- XmtEmergency_Python_rezservet STOPPED
- XmtFileLinkService left exactly as-is
- waiting .RES files left in place
- no manual file movement

That preserves the evidence.

OUTPUT
------
A timestamped folder is created:

    Output_YYYYMMDD_HHMMSS

containing:

    XmtFileLink_Live_State_Report.txt

Send that report back for analysis.

POWERSHELL UNBLOCKING
---------------------
RUN_CHECK_AS_ADMIN.cmd automatically attempts Unblock-File on the packaged PS1
before running it. This is included because downloaded PowerShell files can be
blocked by Windows execution-policy/Zone.Identifier behavior.
