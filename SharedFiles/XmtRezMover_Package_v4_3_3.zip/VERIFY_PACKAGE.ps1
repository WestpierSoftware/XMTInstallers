﻿$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot
$tests = @()
function Add-Test($Name,$Pass) { $script:tests += [pscustomobject]@{Test=$Name;Pass=[bool]$Pass} }

$mover = Get-Content (Join-Path $Root "XmtRezMover.ps1") -Raw
$cfg = Get-Content (Join-Path $Root "XmtRezMover.config.psd1") -Raw
$svcPy = Get-Content (Join-Path $Root "XmtRezMover_Python_Service\XmtRezMoverService.py") -Raw
$svcJson = Get-Content (Join-Path $Root "XmtRezMover_Python_Service\XmtRezMoverService.json") -Raw | ConvertFrom-Json
$installer = Get-Content (Join-Path $Root "INSTALL_XmtRezMover.ps1") -Raw

Add-Test "Mover config startup fix present" (-not ($mover -match '\[string\]\$ConfigFile\s*=\s*\(Join-Path'))
Add-Test "Single-instance lock retained" ($mover -match 'XmtRezMover\.instance\.lock')
Add-Test "Operational LogDir E:\XmtRezMover" ($cfg -match "LogDir\s*=\s*'E:\\XmtRezMover'")
Add-Test "Service internal name XmtRezMover" ($svcPy -match '_svc_name_\s*=\s*"XmtRezMover"')
Add-Test "Service log dir E:\XmtRezMover" ($svcJson.service_log_dir -eq 'E:\XmtRezMover')
Add-Test "Service poll/retry 30 seconds" ([int]$svcJson.poll_seconds -eq 30)
Add-Test "Explicit service config path" ($svcJson.config_file -eq 'C:\WestPier\Installed\XmtRezMover\XmtRezMover.config.psd1')
Add-Test "Installer uses service name XmtRezMover" ($installer -match '\$ServiceName\s*=\s*"XmtRezMover"')
Add-Test "Installer unblocks PowerShell" ($installer -match 'Unblock-File')
Add-Test "Qatar path typo absent" (-not ($cfg -match 'xmtrezqatest\\Downloadd'))


Add-Test "Installer resolves real Python via sys.executable" ($installer -match 'sys\.executable')
Add-Test "Installer avoids PythonPrefix alias handling" (-not ($installer -match '\$PythonPrefix'))


Add-Test "pywin32 update options precede command" ($installer -match '\$ServiceScript,"--startup","auto","update"')
Add-Test "pywin32 install options precede command" ($installer -match '\$ServiceScript,"--startup","auto","install"')


$CollisionText = Get-Content -LiteralPath (Join-Path $Root "Clear-XmtRezMover-Collisions.ps1") -Raw
Add-Test "Missing state file exits cleanly" ($CollisionText -match 'No XmtRezMover_state\.json found - no pending collisions\.')
Add-Test "Empty state file exits cleanly" ($CollisionText -match 'XmtRezMover_state\.json is empty - no pending collisions\.')
Add-Test "No collision entries exits cleanly" ($CollisionText -match 'No pending TARGET_COLLISION entries found\.')
Add-Test "Invalid JSON still errors" ($CollisionText -match 'State file is not valid JSON')

$tests | Format-Table -AutoSize
if ($tests.Pass -contains $false) { exit 1 }
Write-Host ""
Write-Host "VERIFY PASSED" -ForegroundColor Green
