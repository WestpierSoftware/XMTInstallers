@echo off
setlocal
cd /d "%~dp0"

echo.
echo XmtRezMover v4.3.3 Installer
echo =====================================
echo.

rem Self-elevate. Production operator should only need to run this one file.
net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Requesting Administrator rights...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

rem Remove Windows downloaded-file markers before invoking PowerShell.
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%~dp0' -Filter '*.ps1' -File -Recurse | Unblock-File -ErrorAction SilentlyContinue"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL_XmtRezMover.ps1"
set RC=%ERRORLEVEL%

echo.
if "%RC%"=="0" (
    echo SUCCESS - XmtRezMover installation completed.
) else (
    echo FAILED - ExitCode=%RC%
)
echo.
pause
exit /b %RC%
