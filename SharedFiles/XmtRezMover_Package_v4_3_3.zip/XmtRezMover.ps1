﻿# XmtRezMover v4.2
# Continuous safe multi-route mover. Configuration is external.
# v4.2: robust config-path resolution for service launches; logs/state moved to E:\XmtRezMover.
# Retains v4 cross-session single-instance lock and existing safety behaviour.

param(
    [string]$ConfigFile = ""
)

# Resolve the default configuration only AFTER parameter binding.
# This avoids Join-Path failing if $PSScriptRoot is empty in a service launch context.
if ([string]::IsNullOrWhiteSpace($ConfigFile)) {
    $scriptDirectory = $PSScriptRoot
    if ([string]::IsNullOrWhiteSpace($scriptDirectory)) {
        if (-not [string]::IsNullOrWhiteSpace($PSCommandPath)) {
            $scriptDirectory = Split-Path -Parent $PSCommandPath
        }
    }
    if ([string]::IsNullOrWhiteSpace($scriptDirectory)) {
        $scriptDirectory = (Get-Location).Path
    }
    $ConfigFile = Join-Path $scriptDirectory 'XmtRezMover.config.psd1'
}

$ConfigFile = [System.IO.Path]::GetFullPath($ConfigFile)

if (-not (Test-Path -LiteralPath $ConfigFile)) {
    throw "Configuration file not found: $ConfigFile"
}

$Config = Import-PowerShellDataFile -LiteralPath $ConfigFile
$Routes = @($Config.Routes | ForEach-Object { [pscustomobject]$_ })

$LogDir                 = $Config.LogDir
$LogFile                = Join-Path $LogDir 'XmtRezMover.log'
$PollSeconds            = [int]$Config.PollSeconds
$MinimumAgeSeconds      = [int]$Config.MinimumAgeSeconds
$WarningReminderSeconds = [int]$Config.WarningReminderSeconds
$HeartbeatSeconds       = [int]$Config.HeartbeatSeconds
$StateFile              = Join-Path $LogDir 'XmtRezMover_state.json'
$InstanceLockFile       = Join-Path $LogDir 'XmtRezMover.instance.lock'

if ([string]::IsNullOrWhiteSpace($LogDir)) { throw 'Config LogDir cannot be blank.' }
if (-not $Routes -or $Routes.Count -eq 0) { throw 'Config contains no routes.' }

New-Item -ItemType Directory -Force -Path $LogDir | Out-Null


# --------------------------------------------------------------------
# LOGGING
# --------------------------------------------------------------------

function Write-Log {
    param(
        [ValidateSet("INFO","WARN","ERROR")]
        [string]$Level,
        [string]$Message
    )

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -LiteralPath $LogFile -Value "$timestamp $Level $Message"
}


# --------------------------------------------------------------------
# SINGLE INSTANCE SAFETY
# --------------------------------------------------------------------
#
# Hold an exclusive FileStream open for the entire lifetime of XmtRezMover.
# This works across Windows sessions, so a service instance and an interactive
# command-line instance cannot both run on the same machine.
#
# The operating system releases the handle automatically if PowerShell or the
# service terminates unexpectedly. The small .lock file may remain on disk;
# that is harmless. Exclusivity is controlled by the open handle, not existence.

$script:InstanceLockStream = $null

function Acquire-InstanceLock {
    try {
        $script:InstanceLockStream = [System.IO.File]::Open(
            $InstanceLockFile,
            [System.IO.FileMode]::OpenOrCreate,
            [System.IO.FileAccess]::ReadWrite,
            [System.IO.FileShare]::None
        )

        $script:InstanceLockStream.SetLength(0)

        $lockText = (
            "PID={0}`r`nStarted={1}`r`nComputer={2}`r`nUser={3}`r`nScript={4}`r`n" -f
            $PID,
            (Get-Date -Format "o"),
            $env:COMPUTERNAME,
            [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,
            $PSCommandPath
        )

        $bytes = [System.Text.Encoding]::UTF8.GetBytes($lockText)
        $script:InstanceLockStream.Write($bytes, 0, $bytes.Length)
        $script:InstanceLockStream.Flush()

        Write-Log "INFO" "INSTANCE LOCK acquired PID=$PID LOCK=$InstanceLockFile"
        return $true
    }
    catch [System.IO.IOException] {
        Write-Log "WARN" "INSTANCE START BLOCKED - another XmtRezMover instance is already running. PID=$PID LOCK=$InstanceLockFile"
        return $false
    }
    catch {
        Write-Log "ERROR" "INSTANCE LOCK failure - $($_.Exception.Message)"
        throw
    }
}

function Release-InstanceLock {
    if ($null -ne $script:InstanceLockStream) {
        try {
            $script:InstanceLockStream.Dispose()
            $script:InstanceLockStream = $null
            Write-Log "INFO" "INSTANCE LOCK released PID=$PID"
        }
        catch {
            Write-Log "ERROR" "INSTANCE LOCK release failed - $($_.Exception.Message)"
        }
    }
}

if (-not (Acquire-InstanceLock)) {
    exit 2
}


# --------------------------------------------------------------------
# STATE / LOG SUPPRESSION
# --------------------------------------------------------------------

$script:State = @{}

function Save-State {
    try {
        if ($script:State.Count -eq 0) {
            if (Test-Path -LiteralPath $StateFile) {
                Remove-Item -LiteralPath $StateFile -Force -ErrorAction SilentlyContinue
            }
            return
        }

        $obj = [ordered]@{}
        foreach ($key in $script:State.Keys) {
            $obj[$key] = $script:State[$key]
        }

        $obj |
            ConvertTo-Json -Depth 6 |
            Set-Content -LiteralPath $StateFile -Encoding UTF8
    }
    catch {
        Write-Log "ERROR" "STATE save failed - $($_.Exception.Message)"
    }
}

function Load-State {
    $script:State = @{}

    try {
        if (-not (Test-Path -LiteralPath $StateFile)) {
            return
        }

        $saved = Get-Content -LiteralPath $StateFile -Raw -ErrorAction Stop |
            ConvertFrom-Json -ErrorAction Stop

        if ($null -ne $saved) {
            foreach ($p in $saved.PSObject.Properties) {
                $script:State[$p.Name] = $p.Value
            }
        }
    }
    catch {
        $script:State = @{}
        Write-Log "ERROR" "STATE load failed; starting with empty state - $($_.Exception.Message)"
    }
}

function Set-DeferState {
    param(
        [string]$Key,
        [string]$Reason,
        [string]$Message
    )

    $now = Get-Date
    $existing = $script:State[$Key]

    if ($null -eq $existing -or $existing.Reason -ne $Reason) {
        Write-Log "WARN" $Message

        $script:State[$Key] = [pscustomobject]@{
            Reason     = $Reason
            FirstSeen  = $now.ToString("o")
            LastLogged = $now.ToString("o")
        }

        Save-State
        return
    }

    $last = [datetime]$existing.LastLogged
    if (($now - $last).TotalSeconds -ge $WarningReminderSeconds) {
        Write-Log "WARN" "$Message - still deferred"
        $existing.LastLogged = $now.ToString("o")
        Save-State
    }
}

function Clear-DeferState {
    param(
        [string]$Key,
        [string]$ResumeMessage
    )

    if ($script:State.ContainsKey($Key)) {
        $script:State.Remove($Key)
        Save-State
        Write-Log "INFO" $ResumeMessage
    }
}


# --------------------------------------------------------------------
# FILE SAFETY
# --------------------------------------------------------------------

function Test-FileUnlocked {
    param([string]$Path)

    try {
        $stream = [System.IO.File]::Open(
            $Path,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            [System.IO.FileShare]::None
        )
        $stream.Close()
        return $true
    }
    catch {
        return $false
    }
}

function Normalize-Extension {
    param([string]$Extension)

    if ([string]::IsNullOrWhiteSpace($Extension)) {
        throw "Extension cannot be blank"
    }

    if ($Extension.StartsWith(".")) {
        return $Extension
    }

    return ".$Extension"
}

function Get-FileHashValue {
    param([string]$Path)

    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash
}

function Get-TargetInfo {
    param(
        [pscustomobject]$Route,
        [System.IO.FileInfo]$SourceFile
    )

    $holdExt   = Normalize-Extension $Route.HoldExtension
    $targetExt = Normalize-Extension $Route.TargetExtension

    $holdName  = "$($SourceFile.BaseName)$holdExt"
    $finalName = "$($SourceFile.BaseName)$targetExt"

    [pscustomobject]@{
        HoldName  = $holdName
        FinalName = $finalName
        HoldPath  = Join-Path $Route.TargetDir $holdName
        FinalPath = Join-Path $Route.TargetDir $finalName
    }
}


# --------------------------------------------------------------------
# ROUTE / CANDIDATE CHECKS
# --------------------------------------------------------------------

function Test-RouteAvailable {
    param([pscustomobject]$Route)

    $sourceKey = "ROUTE|$($Route.Name)|SOURCE"
    $targetKey = "ROUTE|$($Route.Name)|TARGET"

    if (-not (Test-Path -LiteralPath $Route.SourceDir)) {
        Set-DeferState `
            -Key $sourceKey `
            -Reason "SOURCE_UNAVAILABLE" `
            -Message "ROUTE=$($Route.Name) source unavailable: $($Route.SourceDir)"
        return $false
    }

    Clear-DeferState `
        -Key $sourceKey `
        -ResumeMessage "ROUTE=$($Route.Name) source available again: $($Route.SourceDir)"

    if (-not (Test-Path -LiteralPath $Route.TargetDir)) {
        Set-DeferState `
            -Key $targetKey `
            -Reason "TARGET_UNAVAILABLE" `
            -Message "ROUTE=$($Route.Name) target unavailable: $($Route.TargetDir)"
        return $false
    }

    Clear-DeferState `
        -Key $targetKey `
        -ResumeMessage "ROUTE=$($Route.Name) target available again: $($Route.TargetDir)"

    return $true
}

function Get-AllCandidates {
    $candidates = @()

    foreach ($route in $Routes | Where-Object { $_.Enabled }) {

        if (-not (Test-RouteAvailable $route)) {
            continue
        }

        if ([string]::IsNullOrWhiteSpace($route.SourceFilter)) {
            Set-DeferState `
                -Key "ROUTE|$($route.Name)|FILTER" `
                -Reason "FILTER_BLANK" `
                -Message "ROUTE=$($route.Name) SourceFilter is blank"
            continue
        }

        try {
            $files = Get-ChildItem `
                -LiteralPath $route.SourceDir `
                -Filter $route.SourceFilter `
                -File `
                -ErrorAction Stop |
                Where-Object {
                    ((Get-Date) - $_.LastWriteTime).TotalSeconds -ge $MinimumAgeSeconds
                }

            foreach ($file in $files) {
                $candidates += [pscustomobject]@{
                    Route = $route
                    File  = $file
                }
            }
        }
        catch {
            Set-DeferState `
                -Key "ROUTE|$($route.Name)|SCAN" `
                -Reason "SOURCE_SCAN_ERROR" `
                -Message "ROUTE=$($route.Name) source scan failed: $($_.Exception.Message)"
        }
    }

    return @(
        $candidates |
            Sort-Object { $_.File.LastWriteTime }, { $_.File.Name }
    )
}


# --------------------------------------------------------------------
# PROCESS ONE FILE
# --------------------------------------------------------------------

function Move-OneFile {
    param(
        [pscustomobject]$Route,
        [System.IO.FileInfo]$SourceFile
    )

    $target = Get-TargetInfo -Route $Route -SourceFile $SourceFile

    $fileKey = "FILE|$($SourceFile.FullName)"
    $collisionKey = "$fileKey|COLLISION"
    $lockKey      = "$fileKey|LOCK"

    # Reconfirm source still exists.
    if (-not (Test-Path -LiteralPath $SourceFile.FullName)) {
        Clear-DeferState -Key $collisionKey -ResumeMessage "SOURCE=$($SourceFile.Name) no longer present; collision state cleared"
        Clear-DeferState -Key $lockKey      -ResumeMessage "SOURCE=$($SourceFile.Name) no longer present; lock state cleared"
        return "SKIPPED"
    }

    # Never process a source still being written.
    if (-not (Test-FileUnlocked $SourceFile.FullName)) {
        Set-DeferState `
            -Key $lockKey `
            -Reason "SOURCE_LOCKED" `
            -Message "ROUTE=$($Route.Name) SOURCE=$($SourceFile.Name) deferred - source file locked"
        return "DEFERRED"
    }

    Clear-DeferState `
        -Key $lockKey `
        -ResumeMessage "ROUTE=$($Route.Name) SOURCE=$($SourceFile.Name) source lock cleared; retrying"

    # Reconfirm target path is accessible immediately before copy.
    if (-not (Test-Path -LiteralPath $Route.TargetDir)) {
        Set-DeferState `
            -Key "ROUTE|$($Route.Name)|TARGET" `
            -Reason "TARGET_UNAVAILABLE" `
            -Message "ROUTE=$($Route.Name) target unavailable: $($Route.TargetDir)"
        return "DEFERRED"
    }

    $holdExists  = Test-Path -LiteralPath $target.HoldPath
    $finalExists = Test-Path -LiteralPath $target.FinalPath

    # Collision detection: NEVER overwrite, NEVER auto-suffix.
    if ($holdExists -or $finalExists) {
        Set-DeferState `
            -Key $collisionKey `
            -Reason "TARGET_COLLISION" `
            -Message (
                "ROUTE=$($Route.Name) SOURCE=$($SourceFile.Name) DEFER collision " +
                "HOLD=$($target.HoldName) HOLD_EXISTS=$holdExists " +
                "FINAL=$($target.FinalName) FINAL_EXISTS=$finalExists"
            )

        return "DEFERRED"
    }

    Clear-DeferState `
        -Key $collisionKey `
        -ResumeMessage "ROUTE=$($Route.Name) SOURCE=$($SourceFile.Name) RESUME previous target collision cleared"

    $sourceLength = $SourceFile.Length
    $sourceHash = $null

    try {
        # Hash SOURCE before copy. Source is still present and locked test passed.
        $sourceHash = Get-FileHashValue -Path $SourceFile.FullName

        Write-Log "INFO" (
            "START ROUTE=$($Route.Name) SOURCE=$($SourceFile.Name) " +
            "HOLD=$($target.HoldName) TARGET=$($target.FinalName) " +
            "BYTES=$sourceLength SHA256=$sourceHash"
        )

        # COPY SOURCE -> HOLD. No source deletion/move here.
        Copy-Item `
            -LiteralPath $SourceFile.FullName `
            -Destination $target.HoldPath `
            -ErrorAction Stop

        # Verify HOLD.
        $holdItem = Get-Item -LiteralPath $target.HoldPath -ErrorAction Stop

        if ($holdItem.Length -ne $sourceLength) {
            throw "HOLD size verification failed SOURCE=$sourceLength HOLD=$($holdItem.Length)"
        }

        $holdHash = Get-FileHashValue -Path $target.HoldPath
        if ($holdHash -ne $sourceHash) {
            throw "HOLD SHA256 verification failed SOURCE=$sourceHash HOLD=$holdHash"
        }

        Write-Log "INFO" (
            "VERIFY ROUTE=$($Route.Name) SOURCE=$($SourceFile.Name) " +
            "HOLD=$($target.HoldName) BYTES=$sourceLength SHA256=OK"
        )

        # Last-moment collision check before publication.
        if (Test-Path -LiteralPath $target.FinalPath) {
            throw "FINAL target appeared during copy; publication aborted: $($target.FinalPath)"
        }

        # Publish HOLD -> FINAL in the same target directory.
        Rename-Item `
            -LiteralPath $target.HoldPath `
            -NewName $target.FinalName `
            -ErrorAction Stop

        # FINAL must exist.
        if (-not (Test-Path -LiteralPath $target.FinalPath)) {
            throw "FINAL target not found after HOLD rename"
        }

        # Verify FINAL independently before touching SOURCE.
        $finalItem = Get-Item -LiteralPath $target.FinalPath -ErrorAction Stop

        if ($finalItem.Length -ne $sourceLength) {
            throw "FINAL size verification failed SOURCE=$sourceLength FINAL=$($finalItem.Length)"
        }

        $finalHash = Get-FileHashValue -Path $target.FinalPath
        if ($finalHash -ne $sourceHash) {
            throw "FINAL SHA256 verification failed SOURCE=$sourceHash FINAL=$finalHash"
        }

        Write-Log "INFO" (
            "VERIFY ROUTE=$($Route.Name) SOURCE=$($SourceFile.Name) " +
            "TARGET=$($target.FinalName) BYTES=$sourceLength SHA256=OK"
        )

        # SAFETY GATE:
        # Source is deleted ONLY after FINAL exists and matches length + SHA256.
        Remove-Item `
            -LiteralPath $SourceFile.FullName `
            -Force `
            -ErrorAction Stop

        # Confirm source deletion.
        if (Test-Path -LiteralPath $SourceFile.FullName) {
            throw "SOURCE deletion reported success but source still exists"
        }

        Write-Log "INFO" (
            "DONE ROUTE=$($Route.Name) SOURCE=$($SourceFile.Name) " +
            "TARGET=$($target.FinalName) BYTES=$sourceLength SHA256=$sourceHash SOURCE_DELETED=True"
        )

        # Clear any persisted state for this file.
        Clear-DeferState -Key $collisionKey -ResumeMessage "ROUTE=$($Route.Name) SOURCE=$($SourceFile.Name) collision state cleared"
        Clear-DeferState -Key $lockKey      -ResumeMessage "ROUTE=$($Route.Name) SOURCE=$($SourceFile.Name) lock state cleared"

        return "DONE"
    }
    catch {
        $message = $_.Exception.Message

        Write-Log "ERROR" (
            "ROUTE=$($Route.Name) SOURCE=$($SourceFile.Name) " +
            "HOLD=$($target.HoldName) TARGET=$($target.FinalName) - $message"
        )

        # IMPORTANT:
        # Never remove FINAL in error handling.
        #
        # HOLD cleanup is safe only if FINAL does not exist. If FINAL exists,
        # retain everything for manual inspection; SOURCE is also retained unless
        # the source deletion itself was the failing step.
        try {
            $finalNow = Test-Path -LiteralPath $target.FinalPath
            $holdNow  = Test-Path -LiteralPath $target.HoldPath

            if ($holdNow -and -not $finalNow) {
                Remove-Item -LiteralPath $target.HoldPath -Force -ErrorAction Stop
                Write-Log "INFO" "CLEANUP ROUTE=$($Route.Name) removed incomplete HOLD=$($target.HoldName); SOURCE retained"
            }
            elseif ($holdNow -and $finalNow) {
                Write-Log "WARN" "ROUTE=$($Route.Name) HOLD and FINAL both exist after error; neither removed automatically"
            }

            if (Test-Path -LiteralPath $SourceFile.FullName) {
                Write-Log "INFO" "SAFETY ROUTE=$($Route.Name) SOURCE=$($SourceFile.Name) retained after error"
            }
            else {
                Write-Log "WARN" "SAFETY ROUTE=$($Route.Name) SOURCE=$($SourceFile.Name) source no longer exists after error; FINAL must be checked"
            }
        }
        catch {
            Write-Log "ERROR" "ROUTE=$($Route.Name) cleanup check failed - $($_.Exception.Message)"
        }

        return "ERROR"
    }
}


# --------------------------------------------------------------------
# MAIN CONTINUOUS LOOP
# --------------------------------------------------------------------

Load-State

$enabledNames = ($Routes | Where-Object Enabled | ForEach-Object Name) -join ","
$lastHeartbeat = Get-Date

Write-Log "INFO" (
    "STARTUP XmtRezMover EnabledRoutes=$enabledNames " +
    "PollSeconds=$PollSeconds MinimumAgeSeconds=$MinimumAgeSeconds " +
    "WarningReminderSeconds=$WarningReminderSeconds HeartbeatSeconds=$HeartbeatSeconds " +
    "Safety=SIZE+SHA256"
)

try {
    while ($true) {

        $madeProgress = $false
        $candidates = @()

        try {
            $candidates = Get-AllCandidates

            foreach ($candidate in $candidates) {

                # Complete only one successful file per selection pass.
                # Deferred files do NOT block later candidates/routes.
                $result = Move-OneFile `
                    -Route $candidate.Route `
                    -SourceFile $candidate.File

                if ($result -eq "DONE") {
                    $madeProgress = $true
                    break
                }

                # DEFERRED / SKIPPED / ERROR: continue looking for another
                # runnable candidate rather than spinning on this one.
            }
        }
        catch {
            Write-Log "ERROR" "SCAN - $($_.Exception.Message)"
        }

        $now = Get-Date
        if (($now - $lastHeartbeat).TotalSeconds -ge $HeartbeatSeconds) {
            $enabledCount = @($Routes | Where-Object Enabled).Count
            Write-Log "INFO" (
                "HEARTBEAT alive EnabledRoutes=$enabledCount " +
                "Candidates=$($candidates.Count) DeferredStates=$($script:State.Count)"
            )
            $lastHeartbeat = $now
        }

        # If a file was successfully moved, immediately rescan so backlog drains
        # quickly. Otherwise sleep, preventing any tight loop.
        if (-not $madeProgress) {
            Start-Sleep -Seconds $PollSeconds
        }
    }
}
finally {
    Write-Log "INFO" "STOP XmtRezMover"
    Release-InstanceLock
}
