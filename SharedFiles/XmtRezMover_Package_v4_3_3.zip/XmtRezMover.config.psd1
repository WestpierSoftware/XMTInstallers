﻿@{
    LogDir                 = 'E:\XmtRezMover'
    PollSeconds            = 30
    MinimumAgeSeconds      = 30
    WarningReminderSeconds = 300
    HeartbeatSeconds       = 300

    Routes = @(
        @{
            Name            = 'Route1 - (Conn01) PumaLink - Email PumaLink'
            Enabled         = $true
            SourceDir       = 'E:\Pumadatatest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Pumadatatest\Download'
            SourceFilter    = '*.RES'
            HoldExtension   = '.HLD'
            TargetExtension = '.RES'
        }
        @{
            Name            = 'Route2 (Conn10) man BMSDE         - OMARC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtbmsdetest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtbmsdetest\Download'
            SourceFilter    = '*.RES'
            HoldExtension   = '.HLD'
            TargetExtension = '.RES'
        }
        @{
            Name            = 'Route3 (Conn18) Czech Republic    - PRGRC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezcstest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezcstest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route4 (Conn19) Turkey            - HUNRC/ISTRC/TBSRC/UKRRC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtreztrtest\\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtreztrtest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route5 (Conn22) U.A.E.            - UAERC '
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezx1test\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezx1test\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route6 (Conn24) Greece            - ATHRC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezgr2test\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezgr2test\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route7 (Conn25) Lebanon           - BEYRG '
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezlbtest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezlbtest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route8 (Conn26) Bahrain           - BAHRC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezbhtest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezbhtest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route9 (Conn29) Ireland ROI       - DUBRC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezietest\HoldingSouth\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezietest\HoldingSouth\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route10 (Conn03) France            - FRNRC/FRNAV'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezfrtest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezfrtest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route11 (Conn30) Northern Ireland  - UNKRC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezietest\HoldingNorth\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezietest\HoldingNorth\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route12 (Conn31) Qatar             - DOHRC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezqatest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezqatest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route13 (Conn32) Israel            - TLVRC '
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtreziltest\Holding'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtreziltest\Holding'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route14 (Conn34) Cyprus            - CYPRC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezcytest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezcytest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route15 (Conn36) Slovakia          - QVCRC '
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezqvtest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezqvtest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route16 (Conn37) Saudi Arabia      - JEDRC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezsatest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezsatest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route17 (Conn09) Malta - Morocco SwitzBMSReused - CMNRC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezmatest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezmatest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route18 (Conn02) Italy             - ITARC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezittest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezittest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route19 (Conn23)  Kenya            - KNYRC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezketest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezketest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route20 (Conn16) Poland            - WAWRC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezpltest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezpltest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route21 (Conn35) France Rentals    - FRNRE'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezractest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezractest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route22 (Conn33) Romania RO        - ROMRC '
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtrezrotest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtrezrotest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route23 (Conn27) Toga              - LWFRG '
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtreztgtest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtreztgtest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
        @{
            Name            = 'Route24 (Conn08) Austria BMS       - ASTRC'
            Enabled         = $true
            SourceDir       = 'E:\Reztest\xmtbmsattest\Download'
            TargetDir       = '\\beudc1del01.ad.budgetemea.net\repository\LoadTest_XmtRezMover\Reztest\xmtbmsattest\Download'
            SourceFilter    = '*.XML'
            HoldExtension   = '.TMP'
            TargetExtension = '.XML'
        }
    )
}
