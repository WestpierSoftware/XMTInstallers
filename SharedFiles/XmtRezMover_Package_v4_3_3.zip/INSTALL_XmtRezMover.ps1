﻿$ErrorActionPreference = "Stop"

$ServiceName = "XmtRezMover"
$InstallDir  = "C:\WestPier\Installed\XmtRezMover"
$ServiceDir  = Join-Path $InstallDir "XmtRezMover_Python_Service"
$LogDir      = "E:\XmtRezMover"
$PackageDir  = $PSScriptRoot
$PackageSvc  = Join-Path $PackageDir "XmtRezMover_Python_Service"
$Stamp       = Get-Date -Format "yyyyMMdd_HHmmss"

function Fail([string]$Message) {
    Write-Host ""
    Write-Host "ERROR: $Message" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "XmtRezMover v4.3.3 Installer"
Write-Host "====================================="
Write-Host "Install: $InstallDir"
Write-Host "Logs:    $LogDir"
Write-Host "Service: $ServiceName"
Write-Host ""

# Administrator check.
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Fail "Administrator rights are required."
}

# Resolve the REAL Python interpreter path.
# Do not trust the WindowsApps python.exe alias as an executable path for service commands.
$PythonExe = $null

$py = Get-Command py.exe -ErrorAction SilentlyContinue
if ($py) {
    $resolved = & $py.Source -3 -c "import sys; print(sys.executable)" 2>$null
    if ($LASTEXITCODE -eq 0 -and $resolved) {
        $candidate = ($resolved | Select-Object -Last 1).Trim()
        if (Test-Path -LiteralPath $candidate) {
            $PythonExe = $candidate
        }
    }
}

if (-not $PythonExe) {
    $python = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($python) {
        $resolved = & $python.Source -c "import sys; print(sys.executable)" 2>$null
        if ($LASTEXITCODE -eq 0 -and $resolved) {
            $candidate = ($resolved | Select-Object -Last 1).Trim()
            if (Test-Path -LiteralPath $candidate) {
                $PythonExe = $candidate
            }
        }
    }
}

if (-not $PythonExe) {
    Fail "A real Python 3 interpreter could not be resolved. WindowsApps aliases are not sufficient."
}

Write-Host "Python: $PythonExe"

# Confirm pywin32 before touching the existing service/files.
& $PythonExe -c "import win32serviceutil, win32service, win32event, servicemanager; print('pywin32 OK')" | Out-Host
if ($LASTEXITCODE -ne 0) {
    Fail "pywin32 is not installed for this Python. Install requirements before deployment."
}

# Validate package files before changing anything.
$required = @(
    "XmtRezMover.ps1",
    "XmtRezMover.config.psd1",
    "Clear-XmtRezMover-Collisions.ps1",
    "XmtRezMover_Python_Service\XmtRezMoverService.py",
    "XmtRezMover_Python_Service\XmtRezMoverService.json"
)
foreach ($rel in $required) {
    if (-not (Test-Path -LiteralPath (Join-Path $PackageDir $rel))) {
        Fail "Package file missing: $rel"
    }
}

# Stop existing service if present.
$existingService = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($existingService -and $existingService.Status -ne "Stopped") {
    Write-Host "Stopping existing $ServiceName ..."
    Stop-Service -Name $ServiceName -Force
    (Get-Service -Name $ServiceName).WaitForStatus("Stopped",[TimeSpan]::FromSeconds(30))
}

# Backup existing installation on upgrades.
if (Test-Path -LiteralPath $InstallDir) {
    $BackupRoot = "C:\WestPier\Backup"
    New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null
    $BackupDir = Join-Path $BackupRoot ("XmtRezMover_" + $Stamp)
    New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null

    Get-ChildItem -LiteralPath $InstallDir -Force -ErrorAction SilentlyContinue |
        ForEach-Object {
            Copy-Item -LiteralPath $_.FullName -Destination $BackupDir -Recurse -Force
        }

    Write-Host "Backup: $BackupDir"
}

New-Item -ItemType Directory -Force -Path $InstallDir,$ServiceDir,$LogDir | Out-Null

# Install application files.
foreach ($name in @("XmtRezMover.ps1","XmtRezMover.config.psd1","Clear-XmtRezMover-Collisions.ps1")) {
    Copy-Item -LiteralPath (Join-Path $PackageDir $name) -Destination (Join-Path $InstallDir $name) -Force
}

# Install complete service support folder.
Get-ChildItem -LiteralPath $PackageSvc -File | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $ServiceDir $_.Name) -Force
}

# Standard unblock of all installed PowerShell scripts.
Get-ChildItem -LiteralPath $InstallDir -Filter "*.ps1" -File -Recurse |
    Unblock-File -ErrorAction SilentlyContinue

$ServiceScript = Join-Path $ServiceDir "XmtRezMoverService.py"

# Install or update the Python service registration using the ACTUAL service name XmtRezMover.
if ($existingService) {
    Write-Host "Updating existing Windows service $ServiceName ..."
    $args = @($ServiceScript,"--startup","auto","update")
    & $PythonExe @args
    if ($LASTEXITCODE -ne 0) {
        Fail "Windows service update failed with exit code $LASTEXITCODE."
    }
} else {
    Write-Host "Installing Windows service $ServiceName ..."
    $args = @($ServiceScript,"--startup","auto","install")
    & $PythonExe @args
    if ($LASTEXITCODE -ne 0) {
        Fail "Windows service installation failed with exit code $LASTEXITCODE."
    }
}

# Start service and verify.
Write-Host "Starting $ServiceName ..."
Start-Service -Name $ServiceName
(Get-Service -Name $ServiceName).WaitForStatus("Running",[TimeSpan]::FromSeconds(30))

Start-Sleep -Seconds 3
$svc = Get-Service -Name $ServiceName
if ($svc.Status -ne "Running") {
    Fail "Service did not remain RUNNING."
}

Write-Host ""
Write-Host "INSTALL COMPLETE" -ForegroundColor Green
Write-Host "Service $ServiceName is RUNNING."
Write-Host "Operational/service logs: $LogDir"
Write-Host ""
Write-Host "Check after about 30 seconds:"
Write-Host "  $LogDir\XmtRezMover.log"
Write-Host "  $LogDir\XmtRezMoverService_YYYYMMDD.log"
