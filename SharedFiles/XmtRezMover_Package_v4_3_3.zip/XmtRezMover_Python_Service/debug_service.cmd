@echo off
setlocal
for /f "delims=" %%P in ('where python 2^>nul') do (set "PY=%%P" & goto :found)
for /f "delims=" %%P in ('where py 2^>nul') do (set "PY=%%P -3" & goto :found)
echo Python not found.
pause
exit /b 1
:found
%PY% "%~dp0XmtRezMoverService.py" debug
pause
