import json, os, sys
base = os.path.dirname(os.path.abspath(__file__))
path = os.path.join(base, "XmtRezMoverService.json")
with open(path, "r", encoding="utf-8-sig") as f:
    cfg = json.load(f)
required = ["script", "config_file", "poll_seconds", "service_log_dir"]
missing = [k for k in required if k not in cfg]
if missing:
    print("ERROR missing:", ", ".join(missing))
    sys.exit(1)
print("OK:", path)
for k in required:
    print(f"{k}: {cfg[k]}")
