@echo off
sc stop XmtRezMover
pause
