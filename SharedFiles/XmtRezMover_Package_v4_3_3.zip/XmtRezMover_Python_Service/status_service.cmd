@echo off
sc query XmtRezMover
pause
