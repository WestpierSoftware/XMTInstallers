@echo off
sc stop XmtRezMover >nul 2>&1
timeout /t 2 /nobreak >nul
sc start XmtRezMover
pause
