import json
import os
import subprocess
from datetime import datetime

import servicemanager
import win32event
import win32service
import win32serviceutil


class XmtRezMoverService(win32serviceutil.ServiceFramework):
    _svc_name_ = "XmtRezMover"
    _svc_display_name_ = "XmtRezMover"
    _svc_description_ = "Supervises the XmtRezMover PowerShell mover."

    def __init__(self, args):
        super().__init__(args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)
        self.stop_requested = False
        self.child = None
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.config_path = os.path.join(self.base_dir, "XmtRezMoverService.json")
        self.settings = self._load_settings()

    def _load_settings(self):
        with open(self.config_path, "r", encoding="utf-8-sig") as f:
            cfg = json.load(f)

        script = cfg["script"]
        config_file = cfg["config_file"]

        return {
            "script": script,
            "config_file": config_file,
            "poll_seconds": max(5, int(cfg.get("poll_seconds", 30))),
            "timeout_seconds": max(0, int(cfg.get("timeout_seconds", 0))),
            "service_log_dir": cfg.get("service_log_dir", r"E:\XmtRezMover"),
        }

    def _log_path(self):
        os.makedirs(self.settings["service_log_dir"], exist_ok=True)
        return os.path.join(
            self.settings["service_log_dir"],
            "XmtRezMoverService_" + datetime.now().strftime("%Y%m%d") + ".log",
        )

    def _log(self, message):
        try:
            with open(self._log_path(), "a", encoding="utf-8") as f:
                f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} {message}\n")
        except Exception:
            pass

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        self.stop_requested = True
        win32event.SetEvent(self.stop_event)
        self._stop_child()
        self._log("SERVICE STOP requested")

    def _stop_child(self):
        p = self.child
        if p is None or p.poll() is not None:
            return
        try:
            self._log(f"RUN STOP PID={p.pid}")
            p.terminate()
            try:
                p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self._log(f"RUN KILL PID={p.pid}")
                p.kill()
                p.wait(timeout=5)
        except Exception as exc:
            self._log(f"RUN STOP ERROR {exc}")

    def _wait_or_stop(self, seconds):
        result = win32event.WaitForSingleObject(self.stop_event, int(seconds * 1000))
        return result == win32event.WAIT_OBJECT_0

    def SvcDoRun(self):
        servicemanager.LogInfoMsg("XmtRezMover starting")
        self._log(
            "SERVICE START "
            f"Script={self.settings['script']} "
            f"Config={self.settings['config_file']} "
            f"PollSeconds={self.settings['poll_seconds']}"
        )

        while not self.stop_requested:
            script = self.settings["script"]
            config_file = self.settings["config_file"]

            if not os.path.isfile(script):
                self._log(f"RUN ERROR script not found: {script}")
                if self._wait_or_stop(self.settings["poll_seconds"]):
                    break
                continue

            if not os.path.isfile(config_file):
                self._log(f"RUN ERROR config not found: {config_file}")
                if self._wait_or_stop(self.settings["poll_seconds"]):
                    break
                continue

            args = [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy", "Bypass",
                "-File", script,
                "-ConfigFile", config_file,
            ]

            self._log("RUN START")
            try:
                with open(self._log_path(), "a", encoding="utf-8") as log_handle:
                    self.child = subprocess.Popen(
                        args,
                        cwd=os.path.dirname(script),
                        stdout=log_handle,
                        stderr=subprocess.STDOUT,
                        creationflags=subprocess.CREATE_NO_WINDOW,
                    )

                    while not self.stop_requested:
                        code = self.child.poll()
                        if code is not None:
                            self._log(f"RUN EXIT ExitCode={code}")
                            break
                        if self._wait_or_stop(1):
                            break

                    if self.stop_requested:
                        self._stop_child()

            except Exception as exc:
                self._log(f"RUN ERROR {type(exc).__name__}: {exc}")
            finally:
                self.child = None

            if not self.stop_requested:
                self._log(f"RUN RETRY waiting {self.settings['poll_seconds']} seconds")
                if self._wait_or_stop(self.settings["poll_seconds"]):
                    break

        self._log("SERVICE STOPPED")
        servicemanager.LogInfoMsg("XmtRezMover stopped")


if __name__ == "__main__":
    win32serviceutil.HandleCommandLine(XmtRezMoverService)
