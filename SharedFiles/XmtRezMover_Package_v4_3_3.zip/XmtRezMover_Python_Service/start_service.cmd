@echo off
sc start XmtRezMover
pause
