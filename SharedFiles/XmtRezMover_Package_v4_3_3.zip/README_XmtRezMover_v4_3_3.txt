XmtRezMover v4.3.3 - STANDARD INSTALL PACKAGE
==============================================

PURPOSE
-------
This is the standard installation package for XmtRezMover.

The operator should need to run ONE file only:

    INSTALL_XmtRezMover.cmd

The launcher self-elevates to Administrator, unblocks downloaded PowerShell
files, installs/updates the program, installs/updates the Windows service,
starts the service, and verifies that it reaches RUNNING.

FINAL LAYOUT
------------
Program:

    C:\WestPier\Installed\XmtRezMover\
        XmtRezMover.ps1
        XmtRezMover.config.psd1
        Clear-XmtRezMover-Collisions.ps1
        XmtRezMover_Python_Service\
            XmtRezMoverService.py
            XmtRezMoverService.json
            check_config.py
            start_service.cmd
            stop_service.cmd
            restart_service.cmd
            status_service.cmd
            uninstall_service.cmd
            debug_service.cmd
            requirements.txt

Runtime logs/state:

    E:\XmtRezMover\
        XmtRezMover.log
        XmtRezMover_state.json
        XmtRezMover.instance.lock
        XmtRezMover_collision_cleanup.log
        XmtRezMoverService_YYYYMMDD.log

WINDOWS SERVICE
---------------
Internal service name:

    XmtRezMover

Display name:

    XmtRezMover

The production installer uses the existing XmtRezMover registration if present
and updates it. On a new server it installs XmtRezMover as an
Automatic Windows service.

IMPORTANT: the installer deliberately preserves the existing service registration
on an upgrade where possible. This avoids unnecessarily changing service identity
or other SCM metadata.

STARTUP FIX INCLUDED
--------------------
The earlier service failure:

    Join-Path : Cannot bind argument to parameter 'Path' because it is an empty string.

is fixed. XmtRezMover.ps1 no longer evaluates Join-Path against $PSScriptRoot
inside the ConfigFile parameter default. The service wrapper also passes the
full -ConfigFile path explicitly.

RESTART / LOG-FILL PROTECTION
-----------------------------
The service wrapper retry interval is:

    30 seconds

A failed PowerShell child is not restarted every second.

POWERSHELL UNBLOCK
------------------
INSTALL_XmtRezMover.cmd automatically removes downloaded-file blocking from the
package PowerShell files before running them.

For manual diagnostics only:

    Unblock-File .\*.ps1

is still a valid command.

DATA-SAFETY BEHAVIOUR RETAINED
------------------------------
The mover retains the existing v4 protections:

    - one mover instance only;
    - source lock/in-use checking;
    - target collision detection;
    - existing targets are never overwritten;
    - SIZE + SHA256 verification;
    - source deletion only after verified final publication;
    - failed/unverified transfers retain source;
    - controlled retry/warning state.

ROUTE CONFIGURATION
-------------------
The supplied XmtRezMover.config.psd1 contains the existing route set from the
test installation. Review production source/target paths before deployment if
production paths differ from test.

The previously identified Qatar source typo is corrected from:

    ...\Downloadd

to:

    ...\Download

PREREQUISITE
------------
Python 3 and pywin32 must already be available on the server.

The installer checks this BEFORE it changes the current installation. If pywin32
is missing, it stops safely and reports the prerequisite instead of partially
installing the service.

INSTALLATION
------------
1. Copy/extract this package to the server.
2. Run:

       INSTALL_XmtRezMover.cmd

3. Accept the Administrator prompt if displayed.
4. Wait for:

       INSTALL COMPLETE
       Service XmtRezMover is RUNNING.

No separate PowerShell commands or service-install commands are required.

UPGRADE SAFETY
--------------
If C:\WestPier\Installed\XmtRezMover already exists, the installer backs it up
under:

    C:\WestPier\Backup\XmtRezMover_YYYYMMDD_HHMMSS

before replacing files.

OPTIONAL PACKAGE VERIFICATION
-----------------------------
Not required for installation.

For a pre-install static check:

    Unblock-File .\VERIFY_PACKAGE.ps1
    .\VERIFY_PACKAGE.ps1

Expected:

    VERIFY PASSED

AFTER INSTALL
-------------
Check after approximately 30 seconds:

    E:\XmtRezMover\XmtRezMoverService_YYYYMMDD.log
    E:\XmtRezMover\XmtRezMover.log

VERSION
-------
v4.3.3


V4.3.1 INSTALLER FIX
--------------------
Python detection now resolves sys.executable and uses the real interpreter.
This avoids Windows App Execution Alias / WindowsApps python.exe being passed
incorrectly as a script argument to the real Python interpreter.

The same package is intended for TEST first and, once validated, unchanged in PROD.


V4.3.2 INSTALLER FIX
--------------------
Corrected pywin32 service command-line ordering.

Correct syntax used by this package:

    python XmtRezMoverService.py --startup auto update

or for a new service:

    python XmtRezMoverService.py --startup auto install

The prior v4.3.1 package put --startup after update/install, causing pywin32
to print its Usage screen and return exit code 1.

The same v4.3.2 package is intended for TEST first and then unchanged in PROD.


V4.3.3 COLLISION UTILITY FIX
----------------------------
Clear-XmtRezMover-Collisions.ps1 now treats these as normal success conditions:

    - XmtRezMover_state.json does not exist;
    - XmtRezMover_state.json is empty;
    - the state file contains no TARGET_COLLISION entries.

In those cases it logs a short INFO message and exits with code 0.

Invalid/corrupt JSON remains an ERROR and exits non-zero.

The mover/service/installer logic is otherwise unchanged from the proven v4.3.2 build.

The same v4.3.3 package is intended for TEST first and later PROD, with only the
environment-specific XmtRezMover.config.psd1 paths adjusted before installation.
