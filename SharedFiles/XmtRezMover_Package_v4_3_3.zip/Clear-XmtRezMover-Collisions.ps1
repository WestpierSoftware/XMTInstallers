﻿param(
    [switch]$Delete,
    [switch]$IncludeHold,

    # TARGET is normal collision recovery. SOURCE is primarily for inspection.
    [ValidateSet('SOURCE','TARGET')]
    [string]$Directory = 'TARGET',

    # Extra safety gate: SOURCE cannot be deleted with -Delete alone.
    [switch]$AllowSourceDelete,

    [string]$ConfigFile = ""
)

# Resolve default config after parameter binding.
if ([string]::IsNullOrWhiteSpace($ConfigFile)) {
    $scriptDirectory = $PSScriptRoot
    if ([string]::IsNullOrWhiteSpace($scriptDirectory) -and
        -not [string]::IsNullOrWhiteSpace($PSCommandPath)) {
        $scriptDirectory = Split-Path -Parent $PSCommandPath
    }
    if ([string]::IsNullOrWhiteSpace($scriptDirectory)) {
        $scriptDirectory = (Get-Location).Path
    }
    $ConfigFile = Join-Path $scriptDirectory 'XmtRezMover.config.psd1'
}

$ConfigFile = [System.IO.Path]::GetFullPath($ConfigFile)

if (-not (Test-Path -LiteralPath $ConfigFile)) {
    throw "Configuration file not found: $ConfigFile"
}

$Config = Import-PowerShellDataFile -LiteralPath $ConfigFile
$Routes = @($Config.Routes | ForEach-Object { [pscustomobject]$_ })
$LogDir = $Config.LogDir
$StateFile = Join-Path $LogDir 'XmtRezMover_state.json'
$AuditLog = Join-Path $LogDir 'XmtRezMover_collision_cleanup.log'

function Log($Level,$Message) {
    $line="$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $Level $Message"
    Write-Host $line
    Add-Content -LiteralPath $AuditLog -Value $line
}

function Normalize-Dir([string]$Path) {
    [IO.Path]::GetFullPath($Path).TrimEnd('\')
}

if ($Directory -eq 'SOURCE' -and $Delete -and -not $AllowSourceDelete) {
    throw 'SOURCE deletion blocked. Use -Directory SOURCE -Delete -AllowSourceDelete only if source deletion is genuinely intended.'
}
if (!(Test-Path -LiteralPath $StateFile)) {
    Log INFO "No XmtRezMover_state.json found - no pending collisions."
    Log INFO "COMPLETE Directory=$Directory Collisions=0"
    exit 0
}

$rawState = Get-Content -LiteralPath $StateFile -Raw
if ([string]::IsNullOrWhiteSpace($rawState)) {
    Log INFO "XmtRezMover_state.json is empty - no pending collisions."
    Log INFO "COMPLETE Directory=$Directory Collisions=0"
    exit 0
}

try {
    $state = $rawState | ConvertFrom-Json
}
catch {
    Log ERROR "State file is not valid JSON: $StateFile - $($_.Exception.Message)"
    exit 1
}

$entries=@($state.PSObject.Properties | Where-Object {
    $_.Name -like 'FILE|*|COLLISION' -and $_.Value.Reason -eq 'TARGET_COLLISION'
})

if ($entries.Count -eq 0) {
    Log INFO "No pending TARGET_COLLISION entries found."
    Log INFO "COMPLETE Directory=$Directory Collisions=0"
    exit 0
}

Log INFO "START Mode=$(if($Delete){'DELETE'}else{'DRY-RUN'}) Directory=$Directory Entries=$($entries.Count) IncludeHold=$IncludeHold"

foreach($e in $entries) {
    $src=$e.Name.Substring(5,$e.Name.Length-15)
    $sourceDir=Split-Path -Parent $src
    $base=[IO.Path]::GetFileNameWithoutExtension($src)

    $r=$Routes | Where-Object {
        (Normalize-Dir $_.SourceDir) -ieq (Normalize-Dir $sourceDir)
    } | Select-Object -First 1

    if(!$r) { Log ERROR "No route for collision source: $src"; continue }

    if($Directory -eq 'SOURCE') {
        if(Test-Path -LiteralPath $src) {
            $i=Get-Item -LiteralPath $src
            Log WARN "COLLISION SOURCE ROUTE=$($r.Name) SOURCE=$src BYTES=$($i.Length)"
            if($Delete) {
                try {
                    Remove-Item -LiteralPath $src -Force -ErrorAction Stop
                    Log WARN "DELETED SOURCE ROUTE=$($r.Name) SOURCE=$src"
                } catch { Log ERROR "FAILED SOURCE $src - $($_.Exception.Message)" }
            }
        } else { Log INFO "SOURCE already absent ROUTE=$($r.Name) SOURCE=$src" }
        continue
    }

    if(!(Test-Path -LiteralPath $r.TargetDir)) {
        Log ERROR "Target unavailable ROUTE=$($r.Name): $($r.TargetDir)"
        continue
    }

    $te=if($r.TargetExtension.StartsWith('.')){$r.TargetExtension}else{".$($r.TargetExtension)"}
    $he=if($r.HoldExtension.StartsWith('.')){$r.HoldExtension}else{".$($r.HoldExtension)"}
    $final=Join-Path $r.TargetDir "$base$te"
    $hold=Join-Path $r.TargetDir "$base$he"

    if(Test-Path -LiteralPath $final) {
        $i=Get-Item -LiteralPath $final
        Log INFO "COLLISION FINAL ROUTE=$($r.Name) TARGET=$final BYTES=$($i.Length)"
        if($Delete) {
            try { Remove-Item -LiteralPath $final -Force -ErrorAction Stop; Log INFO "DELETED FINAL $final" }
            catch { Log ERROR "FAILED FINAL $final - $($_.Exception.Message)" }
        }
    }

    if(Test-Path -LiteralPath $hold) {
        $i=Get-Item -LiteralPath $hold
        Log WARN "COLLISION HOLD ROUTE=$($r.Name) TARGET=$hold BYTES=$($i.Length)"
        if($Delete -and $IncludeHold) {
            try { Remove-Item -LiteralPath $hold -Force -ErrorAction Stop; Log INFO "DELETED HOLD $hold" }
            catch { Log ERROR "FAILED HOLD $hold - $($_.Exception.Message)" }
        } elseif($Delete) {
            Log WARN "HOLD retained; use -Delete -IncludeHold to remove: $hold"
        }
    }
}

Log INFO "COMPLETE Directory=$Directory"

if(!$Delete) {
    Write-Host "`nDRY RUN ONLY - nothing deleted."
    Write-Host "TARGET: .\Clear-XmtRezMover-Collisions.ps1 -Directory TARGET -Delete"
    Write-Host "SOURCE inspection: .\Clear-XmtRezMover-Collisions.ps1 -Directory SOURCE"
    Write-Host "SOURCE deletion requires: -Directory SOURCE -Delete -AllowSourceDelete"
}
