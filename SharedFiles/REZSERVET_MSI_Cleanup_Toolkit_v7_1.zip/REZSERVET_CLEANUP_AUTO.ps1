﻿# REZSERVET MSI Cleanup Toolkit v7.1.1
# Run ONLY via RUN_AS_ADMIN.cmd.
#
# Purpose:
#   Resolve MSI repair failure caused by Windows error 1073 / service already exists.
#   The toolkit:
#     1. Finds the original old REZSERVET MSI.
#     2. Captures the current REZSERVET service configuration.
#     3. Confirms the service is STOPPED.
#     4. Deletes ONLY the conflicting REZSERVET service registration.
#     5. Waits for the service registration to disappear.
#     6. Repairs the old MSI so MSI can recreate its own service cleanly.
#     7. Stops REZSERVET if repair starts it.
#     8. Uninstalls the old MSI.
#     9. Verifies the service and MSI registration are both gone.
#
# Safety:
#   - Does NOT delete MSI registry entries manually.
#   - Does NOT use Win32_Product.
#   - Does NOT delete application folders directly.
#   - Aborts if REZSERVET is running and cannot be stopped.
#   - Aborts if service deletion does not complete.
#   - Logs every step.

$ErrorActionPreference = 'Continue'

$BaseDir = if ($PSScriptRoot -and (Test-Path $PSScriptRoot)) { $PSScriptRoot } else { (Get-Location).Path }
$ParentDir = Split-Path $BaseDir -Parent
$LogDir = Join-Path $BaseDir "Logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

$MainLog       = Join-Path $LogDir "REZSERVET_CLEANUP_SUMMARY.log"
$RepairLog     = Join-Path $LogDir "REZSERVET_REPAIR.log"
$UninstallLog  = Join-Path $LogDir "REZSERVET_UNINSTALL.log"
$ServiceBackup = Join-Path $LogDir "REZSERVET_SERVICE_BEFORE_DELETE.txt"

function Log([string]$Message) {
    "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $Message" |
        Tee-Object -FilePath $MainLog -Append
}

function Get-RezServeMsiRegistration {
    Get-ItemProperty `
      "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*", `
      "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*" `
      -ErrorAction SilentlyContinue |
      Where-Object { $_.DisplayName -match 'REZSERVE' } |
      Select-Object DisplayName,DisplayVersion,Publisher,PSChildName,UninstallString
}

function Get-ServiceState {
    $svc = Get-Service -Name "REZSERVET" -ErrorAction SilentlyContinue
    if ($null -eq $svc) { return "NOT_INSTALLED" }
    return $svc.Status.ToString()
}

function Find-OldMsi {
    $preferredName = "RezServeTServiceSetup.msi"
    $preferredLocal = Join-Path $BaseDir $preferredName

    $candidates = @()

    if (Test-Path $preferredLocal) {
        $candidates += Get-Item $preferredLocal
    } else {
        $candidates += @(Get-ChildItem -Path $ParentDir -Recurse -File -Filter $preferredName -ErrorAction SilentlyContinue)
    }

    if ($candidates.Count -eq 0) {
        $candidates += @(Get-ChildItem -Path $ParentDir -Recurse -File -Filter "*.msi" -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match 'RezServeT|REZSERVET|RezServe.*ServiceSetup' })
    }

    $candidates = @($candidates | Sort-Object FullName -Unique)

    if ($candidates.Count -eq 0) {
        Log "ERROR: No REZSERVET MSI candidate found below $ParentDir"
        return $null
    }

    if ($candidates.Count -eq 1) {
        Log "Selected sole MSI candidate: $($candidates[0].FullName)"
        return $candidates[0].FullName
    }

    Log "Multiple MSI candidates found:"
    foreach ($c in $candidates) {
        Log "Candidate: $($c.FullName) Size=$($c.Length) LastWrite=$($c.LastWriteTime)"
    }

    $exact = @($candidates | Where-Object { $_.Name -ieq $preferredName })
    if ($exact.Count -eq 1) {
        Log "Selected exact filename match: $($exact[0].FullName)"
        return $exact[0].FullName
    }

    $selected = $candidates |
        Sort-Object @{Expression={ [math]::Abs($_.Length - 970752) }}, LastWriteTime |
        Select-Object -First 1

    Log "Selected best historic-size match: $($selected.FullName)"
    return $selected.FullName
}

Log "============================================================"
Log "REZSERVET MSI Cleanup Toolkit v7.1.1"
Log "BaseDir=$BaseDir"
Log "ParentDir=$ParentDir"
Log "Purpose=Resolve MSI repair error 1073 (service already exists)"
Log "============================================================"

$Msi = Find-OldMsi
if (!$Msi) { exit 11 }

$item = Get-Item $Msi -ErrorAction SilentlyContinue
if (!$item) {
    Log "ERROR: Selected MSI cannot be read."
    exit 12
}

Log "MSI=$($item.FullName)"
Log "MSI_Size=$($item.Length)"
Log "MSI_LastWrite=$($item.LastWriteTime)"

try {
    Unblock-File -Path $Msi -ErrorAction Stop
    Log "MSI unblocked/checked."
} catch {
    Log "WARNING: Unblock-File: $($_.Exception.Message)"
}

# Capture MSI registration before touching the service.
$regsBefore = @(Get-RezServeMsiRegistration)
if ($regsBefore.Count -eq 0) {
    Log "WARNING: No REZSERVE MSI registration found before cleanup."
} else {
    foreach ($r in $regsBefore) {
        Log "MSI before: Name=$($r.DisplayName) Version=$($r.DisplayVersion) ProductCode=$($r.PSChildName)"
    }
}

# Capture full service configuration before deleting ONLY the service registration.
Log "Capturing REZSERVET service configuration..."
"===== sc.exe qc REZSERVET =====" | Out-File $ServiceBackup -Encoding utf8
sc.exe qc REZSERVET 2>&1 | Out-File $ServiceBackup -Encoding utf8 -Append
"`r`n===== sc.exe queryex REZSERVET =====" | Out-File $ServiceBackup -Encoding utf8 -Append
sc.exe queryex REZSERVET 2>&1 | Out-File $ServiceBackup -Encoding utf8 -Append
"`r`n===== CIM service details =====" | Out-File $ServiceBackup -Encoding utf8 -Append
Get-CimInstance Win32_Service -Filter "Name='REZSERVET'" -ErrorAction SilentlyContinue |
    Select-Object Name,DisplayName,State,StartMode,PathName,StartName,ProcessId |
    Format-List | Out-File $ServiceBackup -Encoding utf8 -Append
Log "Service backup written: $ServiceBackup"

$state = Get-ServiceState
Log "Service state before controlled delete: $state"

if ($state -ne "NOT_INSTALLED" -and $state -ne "Stopped") {
    Log "Stopping REZSERVET..."
    try {
        Stop-Service -Name "REZSERVET" -Force -ErrorAction Stop
        (Get-Service -Name "REZSERVET").WaitForStatus('Stopped',[TimeSpan]::FromSeconds(30))
        Log "REZSERVET stopped."
    } catch {
        Log "ERROR: Could not stop REZSERVET safely: $($_.Exception.Message)"
        exit 21
    }
}

# Delete ONLY the conflicting service registration.
if ((Get-ServiceState) -ne "NOT_INSTALLED") {
    Log "Deleting conflicting REZSERVET Windows service registration..."
    $deleteOutput = & sc.exe delete REZSERVET 2>&1
    foreach ($line in $deleteOutput) { Log "sc delete: $line" }

    # Wait up to 30 seconds for SCM to release the registration.
    $deleted = $false
    for ($i=1; $i -le 30; $i++) {
        Start-Sleep -Seconds 1
        if ((Get-ServiceState) -eq "NOT_INSTALLED") {
            $deleted = $true
            break
        }
    }

    if (!$deleted) {
        Log "ERROR: REZSERVET is still registered after 30 seconds."
        Log "A reboot or open Services/SCM handle may be preventing deletion."
        Log "MSI repair will NOT be attempted."
        exit 22
    }

    Log "Confirmed: conflicting REZSERVET service registration is gone."
} else {
    Log "REZSERVET service registration is already absent."
}

# Repair old MSI. This should now be able to recreate REZSERVET without 1073.
Log "Starting MSI repair after controlled service removal..."
$repairArgs = "/fa `"$Msi`" /qn /norestart /L*V `"$RepairLog`""
$repair = Start-Process msiexec.exe -Wait -PassThru -ArgumentList $repairArgs
Log "Repair exit code: $($repair.ExitCode)"
Log "Repair log: $RepairLog"

if ($repair.ExitCode -notin 0,3010) {
    Log "ERROR: MSI repair still failed."
    Log "The controlled service deletion succeeded, so review the repair log for the NEW failure."
    exit $repair.ExitCode
}

$afterRepair = Get-ServiceState
Log "Service state after repair: $afterRepair"

if ($afterRepair -eq "NOT_INSTALLED") {
    Log "ERROR: MSI repair succeeded but did not recreate REZSERVET."
    Log "Uninstall will NOT continue automatically."
    exit 23
}

# Stop service if repair started it.
$svc = Get-Service -Name "REZSERVET" -ErrorAction SilentlyContinue
if ($svc -and $svc.Status -ne "Stopped") {
    Log "Stopping REZSERVET before MSI uninstall..."
    try {
        Stop-Service -Name "REZSERVET" -Force -ErrorAction Stop
        (Get-Service -Name "REZSERVET").WaitForStatus('Stopped',[TimeSpan]::FromSeconds(30))
        Log "REZSERVET stopped."
    } catch {
        Log "ERROR: Could not stop REZSERVET before uninstall: $($_.Exception.Message)"
        exit 24
    }
}

# Now uninstall cleanly through MSI.
Log "Starting MSI uninstall..."
$uninstallArgs = "/x `"$Msi`" /qn /norestart /L*V `"$UninstallLog`""
$uninst = Start-Process msiexec.exe -Wait -PassThru -ArgumentList $uninstallArgs
Log "Uninstall exit code: $($uninst.ExitCode)"
Log "Uninstall log: $UninstallLog"

Start-Sleep -Seconds 3

$finalSvc = Get-ServiceState
$regsAfter = @(Get-RezServeMsiRegistration)

Log "Service after uninstall: $finalSvc"

if ($regsAfter.Count -eq 0) {
    Log "MSI registration after uninstall: NONE"
} else {
    foreach ($r in $regsAfter) {
        Log "MSI remains: Name=$($r.DisplayName) Version=$($r.DisplayVersion) ProductCode=$($r.PSChildName)"
    }
}

if ($uninst.ExitCode -in 0,1605,3010 -and $finalSvc -eq "NOT_INSTALLED" -and $regsAfter.Count -eq 0) {
    Log "SUCCESS: Old REZSERVET service and MSI registration removed completely."
    Log "Old REZSERVET cleanup is complete. Stop here; validate the NEW XmtRezServe MSI separately."
    exit 0
}

Log "ATTENTION: Cleanup is not fully complete."
Log "Do NOT manually edit MSI registry entries."
Log "Review the summary, repair and uninstall logs."
exit 30
