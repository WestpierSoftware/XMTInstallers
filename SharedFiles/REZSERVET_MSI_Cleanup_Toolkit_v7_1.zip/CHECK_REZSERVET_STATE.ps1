﻿$ErrorActionPreference='SilentlyContinue'

Write-Host "============================================================"
Write-Host "REZSERVET Windows service"
Write-Host "============================================================"
sc.exe query REZSERVET
Write-Host ""
sc.exe qc REZSERVET

Write-Host ""
Write-Host "============================================================"
Write-Host "REZSERVE MSI registration"
Write-Host "============================================================"

$items = @(
    Get-ItemProperty `
      "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*", `
      "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*" `
      -ErrorAction SilentlyContinue |
      Where-Object { $_.DisplayName -match 'REZSERVE' } |
      Select-Object DisplayName,DisplayVersion,Publisher,PSChildName,UninstallString
)

if ($items.Count -eq 0) {
    Write-Host "No REZSERVE MSI registration found."
} else {
    $items | Format-List
}
