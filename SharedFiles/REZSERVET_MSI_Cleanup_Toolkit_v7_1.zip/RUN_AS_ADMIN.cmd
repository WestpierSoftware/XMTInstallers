@echo off
setlocal
cd /d "%~dp0"

REM v7 - single launcher.
REM Requests Administrator elevation, unblocks toolkit PS1 files,
REM then runs the controlled repair/uninstall workflow.

net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell.exe -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo Unblocking toolkit PowerShell files...
powershell.exe -NoProfile -Command "Get-ChildItem -LiteralPath '%~dp0' -Filter '*.ps1' -File | Unblock-File"

echo Starting REZSERVET v7 controlled cleanup...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0REZSERVET_CLEANUP_AUTO.ps1"

set RC=%ERRORLEVEL%
echo.
echo Exit code: %RC%
echo.
echo Summary log:
echo   %~dp0Logs\REZSERVET_CLEANUP_SUMMARY.log
echo.
echo Service backup:
echo   %~dp0Logs\REZSERVET_SERVICE_BEFORE_DELETE.txt
echo.
pause
exit /b %RC%
