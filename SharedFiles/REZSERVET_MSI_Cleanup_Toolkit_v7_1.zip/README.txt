REZSERVET MSI CLEANUP TOOLKIT v7.1
===================================

PURPOSE
-------
This toolkit has ONE job only:

    Completely remove the OLD MSI-installed REZSERVET product cleanly.

It does NOT install, test, or assume success of the NEW XmtRezServe MSI.

WHY
---
The old MSI repair failed because its custom action tried to create the
REZSERVET Windows service while that service already existed (Windows error 1073).

v7.1 therefore:
1. Finds the original OLD RezServeTServiceSetup.msi.
2. Records the old MSI registration.
3. Backs up the current REZSERVET service configuration.
4. Confirms REZSERVET is stopped, or stops it safely.
5. Deletes ONLY the conflicting REZSERVET Windows service registration.
6. Waits until Windows confirms that registration is gone.
7. Repairs the OLD MSI so that it can recreate its service correctly.
8. Stops REZSERVET if required.
9. Uninstalls the OLD MSI through Windows Installer.
10. Verifies BOTH:
      - REZSERVET Windows service is gone
      - old REZSERVET MSI registration is gone

STOP POINT
----------
When v7.1 reports successful removal of the OLD REZSERVET installation,
STOP THERE.

The NEW XmtRezServe MSI is a separate next-phase test. It is the installer
that originally failed and should be investigated independently after the old
REZSERVET state has been completely removed.

WHAT TO RUN
-----------
Run ONLY:

    RUN_AS_ADMIN.cmd

Do not run the PowerShell scripts separately.

LOGS
----
Logs\REZSERVET_CLEANUP_SUMMARY.log
Logs\REZSERVET_REPAIR.log
Logs\REZSERVET_UNINSTALL.log
Logs\REZSERVET_SERVICE_BEFORE_DELETE.txt

EXPECTED SUCCESS
----------------
The summary should finish with:

    SUCCESS: Old REZSERVET service and MSI registration removed completely.
    Old REZSERVET cleanup is complete. Stop here.

SAFETY
------
Do not manually delete Windows Installer registry entries.
Do not use Win32_Product.
Do not manually remove application folders during this cleanup workflow.

CHECK_REZSERVET_STATE.cmd is read-only and can be used after cleanup.
