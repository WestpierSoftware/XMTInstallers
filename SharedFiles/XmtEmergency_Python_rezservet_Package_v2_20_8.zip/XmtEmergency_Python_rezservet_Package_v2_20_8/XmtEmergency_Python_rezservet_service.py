# XmtEmergency_Python_rezservet service wrapper - package v2.20.8
import os

# Must be set BEFORE importing the worker because its external configuration
# reads this value at module import time.
os.environ["REZSERVET_EXECUTION_MODE"] = "Windows Service"

import servicemanager
import win32event
import win32service
import win32serviceutil

import XmtEmergency_Python_rezservet


class XmtEmergency_Python_rezservetService(win32serviceutil.ServiceFramework):
    _svc_name_ = "XmtEmergency_Python_rezservet"
    _svc_display_name_ = "West Pier XmtEmergency_Python_rezservet"
    _svc_description_ = "Processes reservation records and routes them to configured destinations."

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        servicemanager.LogInfoMsg(
            "XmtEmergency_Python_rezservet SCM stop requested"
        )

        # Tell the worker to stop cleanly. The worker logs the same reason into
        # its operational log when it observes the event.
        XmtEmergency_Python_rezservet.STOP_EVENT.set()
        win32event.SetEvent(self.stop_event)

    def SvcDoRun(self):
        servicemanager.LogInfoMsg(
            "XmtEmergency_Python_rezservet service starting"
        )

        # A pywin32 service process/module may be reused during debug/update
        # operations. Start every genuine service run from a known stop state.
        XmtEmergency_Python_rezservet.STOP_EVENT.clear()
        XmtEmergency_Python_rezservet.STOP_REASON = None

        # shutdown.flag is a one-shot runtime control. A flag left behind from
        # an earlier run must not kill a newly started Windows service.
        stale_flag = XmtEmergency_Python_rezservet.SHUTDOWN_FLAG
        if os.path.exists(stale_flag):
            try:
                os.remove(stale_flag)
                servicemanager.LogInfoMsg(
                    f"Removed stale shutdown flag at service startup: {stale_flag}"
                )
            except Exception as exc:
                servicemanager.LogErrorMsg(
                    f"Cannot remove stale shutdown flag {stale_flag}: {exc}"
                )
                raise

        try:
            os.chdir(XmtEmergency_Python_rezservet.BASE_DIR)
            XmtEmergency_Python_rezservet.main()

            # main() is expected to return only after an explicit stop request.
            reason = XmtEmergency_Python_rezservet.STOP_REASON
            if reason is None:
                servicemanager.LogErrorMsg(
                    "XmtEmergency_Python_rezservet main returned without an explicit stop reason"
                )
            else:
                servicemanager.LogInfoMsg(
                    f"XmtEmergency_Python_rezservet main returned reason={reason}"
                )

        except Exception as exc:
            servicemanager.LogErrorMsg(
                f"XmtEmergency_Python_rezservet service failed: {type(exc).__name__}: {exc}"
            )
            raise

        finally:
            servicemanager.LogInfoMsg(
                "XmtEmergency_Python_rezservet service stopped"
            )


if __name__ == "__main__":
    win32serviceutil.HandleCommandLine(XmtEmergency_Python_rezservetService)
