# XmtEmergency_Python_rezservet_config.py
# Externalised former Configuration Sections B and C.
# Edit this file for environment-specific/tailorable values.
# Safety-critical transaction behaviour is enforced in the main program and is not optional.

import os
import time
import uuid
from datetime import datetime

VERSION = "2.20.8"
BUILD = "2026-09-03 01:38"

PROCESS_START_MONO = time.perf_counter()
RUN_ID = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8]

BASE_DIR = r"E:\Xmt_Emergency_Python_rezservet"
LOG_DIR = r"E:\Xmt_Emergency_Python_rezservet\logs"
ARC_DIR = r"E:\Xmt_Emergency_Python_rezservet\archive"

MAP_INI_PATH = os.path.join(BASE_DIR, "xmtmaptag.ini")
STATUS_FLAG = os.path.join(BASE_DIR, "status.flag")
SHUTDOWN_FLAG = os.path.join(BASE_DIR, "shutdown.flag")

HEARTBEAT_SECS = 120
SLEEP_SECS = 120
DEFAULT_DB_TIMEOUT = 5

# Defensive coexistence with XmtFileLink / SQL Server
DB_LOCK_TIMEOUT_MS = 3000
DB_COMMAND_TIMEOUT = 5
# On PFWIZREZ lock timeout/deadlock, temporarily skip up to this many candidate rows
# in the current cycle. Skipped rows are retried from the start on the next poll.
MAX_LOCK_SKIP_ROWS_PER_CYCLE = 5

PRINT_CONSOLE = True
WRITE_LOGFILE = True

VERBOSE_LOGGING = True
LOG_NO_ROUTE = True
DEBUG_LOGGING = False
LOG_XMTOUT_DIAGNOSTICS = False
DAILY_SUMMARY_ENABLED = True

EXECUTION_MODE = os.environ.get("REZSERVET_EXECUTION_MODE", "Console")

WRITE_XMTSTATS = True
FILL_MISSING_CHAR_WITH_BLANKS = False

# Former Section C - schema/status constants
T_PF    = "dbo.PFWIZREZ"
T_AR1   = "dbo.ZAR1ZAR1"
T_OUT   = "dbo.XMTOUTFL"
T_CFG1  = "dbo.XMTCFG1"
T_CFG2  = "dbo.XMTCFG2"
T_IMFC  = "dbo.XMTIMFC"
T_STATS = "dbo.XMTSTATS"

DUMMY_NO_ROUTE_DEST = "NOROUTE"

PF_ROWID_COL = "XMT_ROWID"
PF_STAT_COL  = "WHSOH"
PF_DR_COL    = "DR"

ZERO   = "0"
INPROG = "I"
DONE   = "C"
ERROR  = "E"

PF_INSNDL_COL = "IHSNDL"
PF_IHSITE_COL = "IHSITE"

TAG_OUTCNF20 = "CNF"
TAG_OUTSEQ20 = "SEQ"

MONTHS = {"JAN":1,"FEB":2,"MAR":3,"APR":4,"MAY":5,"JUN":6,"JUL":7,"AUG":8,"SEP":9,"OCT":10,"NOV":11,"DEC":12}
