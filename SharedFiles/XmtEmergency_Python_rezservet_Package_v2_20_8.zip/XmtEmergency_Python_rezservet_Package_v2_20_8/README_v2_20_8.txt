XmtEmergency_Python_rezservet v2.20.8
========================================

Replace all three Python files and restart the Windows service:
  XmtEmergency_Python_rezservet.py
  XmtEmergency_Python_rezservet_config.py
  XmtEmergency_Python_rezservet_service.py

PFWIZREZ remains the special and most critical lock path. Its v2.20.5+ behaviour is preserved:
non-locking candidate probe, exact XMT_ROWID claim, immediate commit, verified rollback,
per-cycle deferral and no sleeping with an open transaction.

All detected SQL Server lock timeout/deadlock events (1222/1205) in protected operations
are written to the daily dedicated lock log:
  E:\Xmt_Emergency_Python_rezservet\logs\XMTLOCK.YYYYMMDD.log

Coverage in v2.20.8:
- PFWIZREZ: special claim/status handling
- XMTOUTFL: metadata/read/insert handling; no blind INSERT retry
- XMTSTATS: sequence read + insert handling
- XMTCFG1 / XMTCFG2: normal committed reads; no NOLOCK; contention is logged/deferred
- XMTIMFC: explicitly defined as shared read-only config; startup read/count contention logged/deferred
- ZAR1ZAR1: optional archive-copy contention logged, non-fatal

Normal XMTLOG receives a concise warning; detailed DBA evidence stays in XMTLOCK.
Where permissions allow, lock records include SPID, transaction state, wait/blocker data,
row/correlation values, rollback state and action. DBA-only fields may show UNAVAILABLE.

Important: this process can only log a lock it actually encounters. The supplied worker
does not currently contain a business-routing SELECT from XMTIMFC, so v2.20.8 validates
and safely reads/counts XMTIMFC at startup. Any later business read should use the same
committed-read + 1205/1222 logging/defer wrapper.

Suggested test: FileLink + service running, then GOOD -> corrupt/non-IMF -> GOOD.
No service restart should be required and any contention should appear in XMTLOCK.
