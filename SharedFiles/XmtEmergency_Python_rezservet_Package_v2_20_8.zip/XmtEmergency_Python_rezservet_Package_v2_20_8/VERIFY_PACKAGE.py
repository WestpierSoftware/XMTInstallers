from pathlib import Path
import py_compile, sys
base=Path(__file__).resolve().parent
for name in ["XmtEmergency_Python_rezservet.py","XmtEmergency_Python_rezservet_config.py","XmtEmergency_Python_rezservet_service.py"]:
    py_compile.compile(str(base/name), doraise=True)
text=(base/"XmtEmergency_Python_rezservet.py").read_text(encoding="utf-8")
cfg=(base/"XmtEmergency_Python_rezservet_config.py").read_text(encoding="utf-8")
checks={
"Version 2.20.8": 'VERSION = "2.20.8"' in cfg,
"XMTIMFC configured": 'T_IMFC  = "dbo.XMTIMFC"' in cfg,
"PF special probe retained": 'def pending_candidate_nolock' in text,
"PF exact-row claim retained": 'WHERE {PF_ROWID_COL} = ?' in text,
"Dedicated lock log": 'XMTLOCK.' in text,
"Generic lock diagnostics": 'def log_sql_lock_event' in text,
"XMTIMFC monitored": '(T_IMFC, "STARTUP_COUNT")' in text,
"XMTCFG1 protected": 'TransientSqlContention(T_CFG1' in text,
"XMTCFG2 protected": 'TransientSqlContention(T_CFG2' in text,
"XMTOUTFL insert logging": 'T_OUT, "INSERT"' in text,
"XMTSTATS insert logging": 'T_STATS, "INSERT"' in text,
"XMTSTATS sequence logging": 'T_STATS, "READ_NEXT_SEQUENCE"' in text,
"Archive lock logging": 'T_AR1, "ARCHIVE_INSERT"' in text,
}
failed=[]
for k,v in checks.items():
 print(('PASS' if v else 'FAIL'), '-', k)
 if not v: failed.append(k)
if failed: sys.exit(1)
print('ALL CHECKS PASSED')
