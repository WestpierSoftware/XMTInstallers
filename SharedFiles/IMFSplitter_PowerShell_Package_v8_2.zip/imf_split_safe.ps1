﻿# IMFSplitter v8.2
# Replacement for v8
#
# v8.2 change:
#   Files are sorted oldest-first. At the FIRST file younger than MinimumAgeSeconds,
#   the scan of this source directory stops immediately; later/newer files are not
#   individually logged as 'too recent'. The next Directory Set may then be processed
#   by the calling/service cycle.
#   MinimumAgeSeconds is set to 5 seconds.
#
# Preserved v8.1 behaviour:
#   Destination collisions are DEFERRED, never overwritten.
#   A deferred file remains in StageImport and later files continue.
#   The collision is logged once until the destination clears.
#   Collision state is persisted across service/script polling cycles.
#
# GOLDEN RULE:
#   PUL mode first scans the COMPLETE FILE for /PUL occurrences.
#   0 PUL occurrences -> MOVE complete file unchanged to AS400/default route.
#   1 PUL occurrence  -> MOVE complete file unchanged according to that PUL.
#   >1 PUL occurrences -> exceptional SPLIT path:
#                         parse complete reservation blocks, then route each Rez.
#
# Physical lines, blank lines and divider lines are NEVER counted as Rez records.


$InputDir   = "E:\Reztest\StageImport"
$SqlDir     = "E:\Reztest\SQLImport"
$As400Dir   = "E:\Reztest\AS400Import"
$ArchiveDir = "E:\IMFSplitter\IMF\Archive"
$ErrorDir   = "E:\IMFSplitter\IMF\Error"
$LogsDir    = "E:\IMFSplitter\IMF\Logs"

$RoutingMode = "PUL"

$SqlOnlyPulCodes = @(
    "LIS",
    "RNN"
)

$ParallelPulCodes = @(
    "CDG"
)

$SqlOnlyLocCodes = @(
    # "ATH"
)

$ParallelLocCodes = @(
    # "MUC"
)

$WriteSqlOutput   = $true
$WriteAs400Output = $true

$SqlTestRedirectToAs400 = $false
$SqlTestSuffix = "_SQL"

$EnableRouteLogs = $true
$MinimumAgeSeconds = 5
# v8.1 - persistent duplicate/collision log suppression.
# This prevents the same blocked input file filling the service log every poll.
$CollisionStatePath = Join-Path $LogsDir "collision_state.json"
$CollisionLogState = @{}

New-Item -ItemType Directory -Force `
    -Path $InputDir,$SqlDir,$As400Dir,$ArchiveDir,$ErrorDir,$LogsDir | Out-Null

function Get-DailyLogPath {
    param([string]$BaseName)
    $date = Get-Date -Format "yyyyMMdd"
    Join-Path $LogsDir "${BaseName}_${date}.log"
}

function Write-Log {
    param([string]$Message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path (Get-DailyLogPath "imf_split") -Value "$timestamp $Message"
}

function Write-SplitExceptionLog {
    param(
        [System.IO.FileInfo]$File,
        [int]$PulOccurrences,
        [int]$UniquePulCount,
        [string[]]$PulCodes,
        [int]$RezCount,
        [int]$RezMissingPulCount,
        [int]$IgnoredLineCount
    )

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $pulText = if ($PulCodes -and $PulCodes.Count -gt 0) { $PulCodes -join "," } else { "NONE" }
    $path = Join-Path $LogsDir "split_exceptions.log"

    Add-Content -Path $path -Value (
        "$timestamp FILE=$($File.Name) PUL_OCCURRENCES=$PulOccurrences " +
        "UNIQUE_PULS=$UniquePulCount REZ=$RezCount REZ_MISSING_PUL=$RezMissingPulCount " +
        "IGNORED_LINES=$IgnoredLineCount PULS=$pulText REASON=MULTIPLE_PUL"
    )
}

function Test-FileUnlocked {
    param([string]$Path)
    try {
        $stream = [System.IO.File]::Open(
            $Path,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            [System.IO.FileShare]::None
        )
        $stream.Close()
        return $true
    }
    catch {
        return $false
    }
}

function Get-ArchivePath {
    param([System.IO.FileInfo]$File)

    $archiveName = Join-Path $ArchiveDir $File.Name
    if (Test-Path $archiveName) {
        $stamp = Get-Date -Format "yyyyMMdd_HHmmssfff"
        $archiveName = Join-Path $ArchiveDir "$($File.BaseName)_$stamp$($File.Extension)"
    }
    return $archiveName
}

function Get-SqlFinalPath {
    param([System.IO.FileInfo]$File)

    if ($SqlTestRedirectToAs400) {
        $sqlTestName = "$($File.BaseName)$SqlTestSuffix$($File.Extension)"
        return Join-Path $As400Dir $sqlTestName
    }

    return Join-Path $SqlDir $File.Name
}

function Get-Route {
    param(
        [string]$Code,
        [string[]]$SqlOnlyCodes,
        [string[]]$ParallelCodes
    )

    if ($ParallelCodes -contains $Code) {
        return "BOTH"
    }
    elseif ($SqlOnlyCodes -contains $Code) {
        return "SQL"
    }
    else {
        return "AS400"
    }
}

function Write-RouteAudit {
    param(
        [string]$Divider,
        [string[]]$SqlRecords,
        [string[]]$As400Records
    )

    if (-not $EnableRouteLogs) {
        return
    }

    if ($SqlRecords -and $SqlRecords.Count -gt 0) {
        $path = Get-DailyLogPath "routed_to_SqlServer"
        Add-Content -Path $path -Value $Divider
        $SqlRecords | Add-Content -Path $path
    }

    if ($As400Records -and $As400Records.Count -gt 0) {
        $path = Get-DailyLogPath "routed_to_as400"
        Add-Content -Path $path -Value $Divider
        $As400Records | Add-Content -Path $path
    }
}

function Save-CollisionState {
    try {
        if ($CollisionLogState.Count -eq 0) {
            if (Test-Path -LiteralPath $CollisionStatePath) {
                Remove-Item -LiteralPath $CollisionStatePath -Force -ErrorAction SilentlyContinue
            }
            return
        }

        $CollisionLogState |
            ConvertTo-Json -Depth 3 |
            Set-Content -LiteralPath $CollisionStatePath -Encoding UTF8
    }
    catch {
        # Collision-state persistence must never stop routing.
        Write-Log "WARNING unable to save collision state - $($_.Exception.Message)"
    }
}

function Initialize-CollisionState {
    $script:CollisionLogState = @{}

    try {
        if (Test-Path -LiteralPath $CollisionStatePath) {
            $saved = Get-Content -LiteralPath $CollisionStatePath -Raw -ErrorAction Stop |
                ConvertFrom-Json -ErrorAction Stop

            if ($null -ne $saved) {
                foreach ($property in $saved.PSObject.Properties) {
                    $script:CollisionLogState[$property.Name] = [string]$property.Value
                }
            }
        }

        # Remove stale entries whose original StageImport file no longer exists.
        $staleKeys = @(
            $script:CollisionLogState.Keys |
                Where-Object { -not (Test-Path -LiteralPath $_) }
        )

        foreach ($key in $staleKeys) {
            $script:CollisionLogState.Remove($key)
        }

        if ($staleKeys.Count -gt 0) {
            Save-CollisionState
        }
    }
    catch {
        $script:CollisionLogState = @{}
        Write-Log "WARNING unable to load collision state - $($_.Exception.Message)"
    }
}

function Write-CollisionOnce {
    param(
        [System.IO.FileInfo]$File,
        [object]$Collision,
        [string]$SqlFinal,
        [string]$As400Final
    )

    $key = $File.FullName

    if (-not $script:CollisionLogState.ContainsKey($key)) {
        Write-Log "DEFER $($File.Name) - output already exists: SQL=$($Collision.SQL) AS400=$($Collision.AS400) SQLPATH=$SqlFinal AS400PATH=$As400Final"
        $script:CollisionLogState[$key] = (Get-Date -Format "o")
        Save-CollisionState
    }
}

function Clear-CollisionState {
    param([System.IO.FileInfo]$File)

    $key = $File.FullName
    if ($script:CollisionLogState.ContainsKey($key)) {
        $script:CollisionLogState.Remove($key)
        Save-CollisionState
        Write-Log "RESUME $($File.Name) - previous output collision has cleared."
    }
}

function Test-OutputCollision {
    param(
        [string]$Route,
        [string]$SqlFinal,
        [string]$As400Final
    )

    $sqlCollision = $false
    $as400Collision = $false

    if (($Route -eq "SQL" -or $Route -eq "BOTH") -and $WriteSqlOutput) {
        $sqlCollision = Test-Path $SqlFinal
    }

    if (($Route -eq "AS400" -or $Route -eq "BOTH") -and $WriteAs400Output) {
        $as400Collision = Test-Path $As400Final
    }

    [pscustomobject]@{
        Any   = ($sqlCollision -or $as400Collision)
        SQL   = $sqlCollision
        AS400 = $as400Collision
    }
}

function Convert-LinesToRezRecords {
    param([string[]]$Lines)

    $records = @()
    $currentParts = New-Object System.Collections.Generic.List[string]
    $ignoredLines = 0
    $orphanLines = 0

    foreach ($line in $Lines) {
        $trimmed = if ($null -eq $line) { "" } else { $line.Trim() }

        if ([string]::IsNullOrWhiteSpace($trimmed)) {
            $ignoredLines++
            continue
        }

        if ($trimmed -match '^-{3,}$') {
            $ignoredLines++
            continue
        }

        if ($trimmed -match '^/ACT') {
            if ($currentParts.Count -gt 0) {
                $records += ($currentParts -join "")
                $currentParts.Clear()
            }
            [void]$currentParts.Add($trimmed)
            continue
        }

        if ($currentParts.Count -gt 0) {
            [void]$currentParts.Add($trimmed)
        }
        else {
            $ignoredLines++
            $orphanLines++
        }
    }

    if ($currentParts.Count -gt 0) {
        $records += ($currentParts -join "")
    }

    [pscustomobject]@{
        Records          = @($records)
        IgnoredLineCount = $ignoredLines
        OrphanLineCount  = $orphanLines
    }
}

function Publish-WholeFile {
    param(
        [System.IO.FileInfo]$File,
        [string]$Route,
        [string[]]$AuditRecords,
        [int]$InputCount,
        [int]$PulOccurrences,
        [string]$PulCode
    )

    $sqlFinal   = Get-SqlFinalPath $File
    $as400Final = Join-Path $As400Dir $File.Name

    $collision = Test-OutputCollision `
        -Route $Route `
        -SqlFinal $sqlFinal `
        -As400Final $as400Final

    if ($collision.Any) {
        Write-CollisionOnce `
            -File $File `
            -Collision $collision `
            -SqlFinal $sqlFinal `
            -As400Final $as400Final
        return $false
    }

    Clear-CollisionState -File $File

    $archivePath = Get-ArchivePath $File
    Copy-Item -Path $File.FullName -Destination $archivePath -ErrorAction Stop

    $targets = @()

    if (($Route -eq "SQL" -or $Route -eq "BOTH") -and $WriteSqlOutput) {
        $targets += [pscustomobject]@{ Name = "SQL"; Final = $sqlFinal }
    }

    if (($Route -eq "AS400" -or $Route -eq "BOTH") -and $WriteAs400Output) {
        $targets += [pscustomobject]@{ Name = "AS400"; Final = $as400Final }
    }

    if ($targets.Count -eq 0) {
        Remove-Item -Path $File.FullName -Force -ErrorAction Stop
    }
    elseif ($targets.Count -eq 1) {
        $temp = "$($targets[0].Final).tmp"
        Remove-Item $temp -Force -ErrorAction SilentlyContinue
        Move-Item -Path $File.FullName -Destination $temp -ErrorAction Stop
        Move-Item -Path $temp -Destination $targets[0].Final -ErrorAction Stop
    }
    else {
        $firstTemp  = "$($targets[0].Final).tmp"
        $secondTemp = "$($targets[1].Final).tmp"

        Remove-Item $firstTemp,$secondTemp -Force -ErrorAction SilentlyContinue

        Copy-Item -Path $File.FullName -Destination $firstTemp -ErrorAction Stop
        Move-Item -Path $File.FullName -Destination $secondTemp -ErrorAction Stop

        Move-Item -Path $firstTemp  -Destination $targets[0].Final -ErrorAction Stop
        Move-Item -Path $secondTemp -Destination $targets[1].Final -ErrorAction Stop
    }

    $sqlAudit = @()
    $as400Audit = @()

    if ($Route -eq "SQL" -or $Route -eq "BOTH") {
        $sqlAudit = $AuditRecords
    }

    if ($Route -eq "AS400" -or $Route -eq "BOTH") {
        $as400Audit = $AuditRecords
    }

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $sqlMode = if ($SqlTestRedirectToAs400) { "TEST->$SqlTestSuffix" } else { "SQL" }
    $pulDisplay = if ([string]::IsNullOrWhiteSpace($PulCode)) { "NONE" } else { $PulCode }

    $divider = "===== $timestamp FILE=$($File.Name) MODE=$RoutingMode ACTION=MOVE INPUT=$InputCount PUL_OCCURRENCES=$PulOccurrences PUL=$pulDisplay ROUTE=$Route AS400OUT=$WriteAs400Output SQLOUT=$WriteSqlOutput SQLMODE=$sqlMode ====="

    Write-RouteAudit -Divider $divider -SqlRecords $sqlAudit -As400Records $as400Audit

    Write-Log "DONE $($File.Name) MODE=$RoutingMode ACTION=MOVE INPUT=$InputCount PUL_OCCURRENCES=$PulOccurrences PUL=$pulDisplay ROUTE=$Route AS400OUT=$WriteAs400Output SQLOUT=$WriteSqlOutput SQLMODE=$sqlMode"

    return $true
}

function Publish-SplitFile {
    param(
        [System.IO.FileInfo]$File,
        [string[]]$Records,
        [int]$PulOccurrences,
        [string[]]$UniquePuls,
        [int]$IgnoredLineCount,
        [int]$OrphanLineCount
    )

    if (-not $Records -or $Records.Count -eq 0) {
        throw "MULTIPLE_PUL file could not be parsed into any /ACT reservation records."
    }

    $sqlFinal   = Get-SqlFinalPath $File
    $as400Final = Join-Path $As400Dir $File.Name
    $sqlTemp   = "$sqlFinal.tmp"
    $as400Temp = "$as400Final.tmp"

    $sqlCount = 0
    $as400Count = 0
    $bothCount = 0
    $missingPulRezCount = 0

    $sqlRecords = @()
    $as400Records = @()

    $rezNumber = 0
    foreach ($record in $Records) {
        $rezNumber++

        $matches = [regex]::Matches($record, '/PUL([^\\\r\n]+)\\')

        if ($matches.Count -eq 0) {
            $pul = ""
            $route = "AS400"
            $missingPulRezCount++
            Write-Log "WARNING $($File.Name) REZ=$rezNumber - no PUL found; routed AS400."
        }
        else {
            $pul = $matches[0].Groups[1].Value.ToUpperInvariant()

            if ($matches.Count -gt 1) {
                Write-Log "WARNING $($File.Name) REZ=$rezNumber - multiple PUL fields inside one Rez; first PUL=$pul used."
            }

            $route = Get-Route `
                -Code $pul `
                -SqlOnlyCodes $SqlOnlyPulCodes `
                -ParallelCodes $ParallelPulCodes
        }

        if ($route -eq "SQL" -or $route -eq "BOTH") {
            $sqlCount++
            $sqlRecords += $record
        }

        if ($route -eq "AS400" -or $route -eq "BOTH") {
            $as400Count++
            $as400Records += $record
        }

        if ($route -eq "BOTH") {
            $bothCount++
        }
    }

    $requiredRoute =
        if ($sqlCount -gt 0 -and $as400Count -gt 0) { "BOTH" }
        elseif ($sqlCount -gt 0) { "SQL" }
        else { "AS400" }

    $collision = Test-OutputCollision `
        -Route $requiredRoute `
        -SqlFinal $sqlFinal `
        -As400Final $as400Final

    if ($collision.Any) {
        Write-CollisionOnce `
            -File $File `
            -Collision $collision `
            -SqlFinal $sqlFinal `
            -As400Final $as400Final
        return $false
    }

    Clear-CollisionState -File $File

    Write-SplitExceptionLog `
        -File $File `
        -PulOccurrences $PulOccurrences `
        -UniquePulCount $UniquePuls.Count `
        -PulCodes $UniquePuls `
        -RezCount $Records.Count `
        -RezMissingPulCount $missingPulRezCount `
        -IgnoredLineCount $IgnoredLineCount

    if ($OrphanLineCount -gt 0) {
        Write-Log "WARNING $($File.Name) - SPLIT parser ignored $OrphanLineCount non-divider line(s) before first /ACT."
    }

    Remove-Item $sqlTemp,$as400Temp -Force -ErrorAction SilentlyContinue

    if ($WriteSqlOutput -and $sqlCount -gt 0) {
        $sqlRecords | Add-Content -Path $sqlTemp
        Move-Item -Path $sqlTemp -Destination $sqlFinal -ErrorAction Stop
    }

    if ($WriteAs400Output -and $as400Count -gt 0) {
        $as400Records | Add-Content -Path $as400Temp
        Move-Item -Path $as400Temp -Destination $as400Final -ErrorAction Stop
    }

    $archivePath = Get-ArchivePath $File
    Move-Item -Path $File.FullName -Destination $archivePath -ErrorAction Stop

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $sqlMode = if ($SqlTestRedirectToAs400) { "TEST->$SqlTestSuffix" } else { "SQL" }
    $divider = "===== $timestamp FILE=$($File.Name) MODE=PUL ACTION=SPLIT INPUT=$($Records.Count) PUL_OCCURRENCES=$PulOccurrences AS400=$as400Count SQL=$sqlCount BOTH=$bothCount MISSING_PUL_REZ=$missingPulRezCount IGNORED_LINES=$IgnoredLineCount AS400OUT=$WriteAs400Output SQLOUT=$WriteSqlOutput SQLMODE=$sqlMode ====="

    Write-RouteAudit -Divider $divider -SqlRecords $sqlRecords -As400Records $as400Records

    Write-Log "DONE $($File.Name) MODE=PUL ACTION=SPLIT INPUT=$($Records.Count) PUL_OCCURRENCES=$PulOccurrences AS400=$as400Count SQL=$sqlCount BOTH=$bothCount MISSING_PUL_REZ=$missingPulRezCount IGNORED_LINES=$IgnoredLineCount AS400OUT=$WriteAs400Output SQLOUT=$WriteSqlOutput SQLMODE=$sqlMode"

    return $true
}

Initialize-CollisionState

$mode = $RoutingMode.ToUpperInvariant()

if ($mode -ne "PUL" -and $mode -ne "LOC") {
    throw "Invalid RoutingMode '$RoutingMode'. Valid values are PUL or LOC."
}

$inputFiles = Get-ChildItem -Path $InputDir -Filter "*.RES" -File |
    Sort-Object LastWriteTime, Name

foreach ($file in $inputFiles) {

    try {
        $age = (Get-Date) - $file.LastWriteTime

        if ($age.TotalSeconds -lt $MinimumAgeSeconds) {
            Write-Log "SKIP $($file.Name) - too recent; end of this directory scan."
            break
        }

        if (-not (Test-FileUnlocked $file.FullName)) {
            Write-Log "SKIP $($file.Name) - file locked."
            continue
        }

        Write-Log "START $($file.Name) MODE=$mode"

        $lines = @(Get-Content -Path $file.FullName)
        $rawText = Get-Content -Path $file.FullName -Raw

        if ($mode -eq "LOC") {
            $loc = if ($file.BaseName.Length -ge 3) {
                $file.BaseName.Substring(0,3).ToUpperInvariant()
            }
            else {
                ""
            }

            $route = Get-Route `
                -Code $loc `
                -SqlOnlyCodes $SqlOnlyLocCodes `
                -ParallelCodes $ParallelLocCodes

            [void](Publish-WholeFile `
                -File $file `
                -Route $route `
                -AuditRecords $lines `
                -InputCount 1 `
                -PulOccurrences 0 `
                -PulCode $loc)

            continue
        }

        $pulMatches = [regex]::Matches($rawText, '/PUL([^\\\r\n]+)\\')
        $pulOccurrences = $pulMatches.Count

        if ($pulOccurrences -eq 0) {
            [void](Publish-WholeFile `
                -File $file `
                -Route "AS400" `
                -AuditRecords $lines `
                -InputCount 1 `
                -PulOccurrences 0 `
                -PulCode "")

            continue
        }

        if ($pulOccurrences -eq 1) {
            $pul = $pulMatches[0].Groups[1].Value.ToUpperInvariant()

            $route = Get-Route `
                -Code $pul `
                -SqlOnlyCodes $SqlOnlyPulCodes `
                -ParallelCodes $ParallelPulCodes

            [void](Publish-WholeFile `
                -File $file `
                -Route $route `
                -AuditRecords $lines `
                -InputCount 1 `
                -PulOccurrences 1 `
                -PulCode $pul)

            continue
        }

        $uniquePuls = @(
            $pulMatches |
                ForEach-Object { $_.Groups[1].Value.ToUpperInvariant() } |
                Sort-Object -Unique
        )

        $parsed = Convert-LinesToRezRecords -Lines $lines

        [void](Publish-SplitFile `
            -File $file `
            -Records $parsed.Records `
            -PulOccurrences $pulOccurrences `
            -UniquePuls $uniquePuls `
            -IgnoredLineCount $parsed.IgnoredLineCount `
            -OrphanLineCount $parsed.OrphanLineCount)
    }
    catch {
        Write-Log "ERROR $($file.Name) - $($_.Exception.Message)"

        try {
            $sqlFinal = Get-SqlFinalPath $file
            $as400Final = Join-Path $As400Dir $file.Name
            Remove-Item "$sqlFinal.tmp","$as400Final.tmp" `
                -Force -ErrorAction SilentlyContinue
        }
        catch {
        }

        if (Test-Path $file.FullName) {
            $errorName = Join-Path $ErrorDir $file.Name

            if (Test-Path $errorName) {
                $stamp = Get-Date -Format "yyyyMMdd_HHmmssfff"
                $errorName = Join-Path $ErrorDir "$($file.BaseName)_$stamp$($file.Extension)"
            }

            Move-Item -Path $file.FullName `
                -Destination $errorName `
                -ErrorAction SilentlyContinue
        }
    }
}
