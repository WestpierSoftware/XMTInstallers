﻿# READ-ONLY source-code verification for IMFSplitter v8.2
$Script = Join-Path $PSScriptRoot "imf_split_safe.ps1"
$content = Get-Content -LiteralPath $Script -Raw

$tests = @(
    [pscustomobject]@{
        Test = "MinimumAgeSeconds is 5"
        Pass = $content -match '(?m)^\$MinimumAgeSeconds\s*=\s*5\s*$'
    },
    [pscustomobject]@{
        Test = "Input files sorted oldest-first"
        Pass = $content -match 'Sort-Object\s+LastWriteTime,\s*Name'
    },
    [pscustomobject]@{
        Test = "Too-recent branch uses break"
        Pass = $content -match '(?s)if\s*\(\$age\.TotalSeconds\s*-lt\s*\$MinimumAgeSeconds\).*?too recent; end of this directory scan\.".*?break'
    }
)

$tests | Format-Table -AutoSize
if ($tests.Pass -contains $false) { exit 1 }
exit 0
