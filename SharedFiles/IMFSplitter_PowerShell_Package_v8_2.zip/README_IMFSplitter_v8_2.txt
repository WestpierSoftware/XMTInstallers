IMF SPLITTER v8.2 - REBUILD
============================

PURPOSE OF THIS REBUILD
-----------------------
This is a minimal change from the existing v8.1 splitter.

Requested behaviour:

    Within each source Directory Set:
      1. Enumerate *.RES files.
      2. Sort oldest first by LastWriteTime, then Name.
      3. Process eligible files normally.
      4. On the FIRST file that is younger than MinimumAgeSeconds:
            log ONE "too recent" message;
            STOP scanning that source directory immediately.
      5. Do not inspect/log every newer file as "too recent".
      6. The service/calling cycle can then move to the next Directory Set.

CURRENT SETTLING DELAY
----------------------
    $MinimumAgeSeconds = 5

The 5-second delay remains an extra safety cushion. Locked/in-use files are
still skipped and retried according to the existing logic.

WHY BREAK IS CORRECT
--------------------
The source files are already sorted:

    Sort-Object LastWriteTime, Name

Therefore, once the first file is too recent, every file after it in that
directory is at least as new. Continuing through the rest only creates noise
and serves no useful purpose.

EXAMPLE
-------
Before:

    START A.RES
    DONE  A.RES
    SKIP  B.RES - too recent.
    SKIP  C.RES - too recent.
    SKIP  D.RES - too recent.
    SKIP  E.RES - too recent.

v8.2:

    START A.RES
    DONE  A.RES
    SKIP  B.RES - too recent; end of this directory scan.

Then processing can continue with the next Directory Set.

UNCHANGED
---------
All existing routing/safety behaviour from v8.1 is otherwise retained:
- PUL and LOC routing
- Golden Rule:
    0 PUL -> move whole file unchanged
    1 PUL -> move whole file unchanged according to PUL
    >1 PUL -> exceptional split path
- locked-file deferral
- collision deferral / no overwrite
- collision-state persistence
- safe .tmp publication
- route logs
- Archive/Error behaviour

INSTALL
-------
This package is intended as a replacement for the existing:

    imf_split_safe.ps1

Back up the currently installed script first, then replace it with the supplied
v8.2 script.

If the splitter is hosted by a long-running service/wrapper, restart that
service/process so the replacement script/configuration is definitely loaded.

VALIDATION
----------
Expected test:

1. Put several .RES files into a source directory with increasing timestamps.
2. Ensure the first few are >5 seconds old.
3. Ensure a later file is <5 seconds old.
4. Run one scan.
5. Confirm:
      - older eligible files process in order;
      - exactly the first young file logs "too recent";
      - no later files in that directory are logged;
      - later files remain untouched for the next poll;
      - another Directory Set can still be processed by the outer cycle.

VERSION
-------
v8.2
