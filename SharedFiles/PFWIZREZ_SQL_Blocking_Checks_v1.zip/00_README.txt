PFWIZREZ SQL BLOCKING / TIMEOUT CHECK PACKAGE

Purpose: read-only SQL checks for FileLink timeouts/inserts into dbo.PFWIZREZ.

Run order:
1. 01_Quick_Check_Low_Privilege.sql
2. 02_PFWIZREZ_Table_Locks.sql
3. 03_Open_Transactions.sql
4. 04_Enhanced_Blocking_Check.sql (if permitted)
5. 05_Inspect_Blocking_SPID.sql after setting @SPID
6. 06_PFWIZREZ_Object_State.sql

Safety:
- No KILL commands.
- No rollback commands.
- Diagnostic/read-only only.

Reuse later:
In scripts with @TableName, change N'PFWIZREZ' to N'XMTOUTFL' or N'XMTCODES'.

The xmt login may lack VIEW SERVER STATE, so low-privilege and enhanced checks are separated.
