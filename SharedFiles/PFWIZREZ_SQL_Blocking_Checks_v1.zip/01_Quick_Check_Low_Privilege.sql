USE [XMT];
GO
PRINT '01 - QUICK LOW-PRIVILEGE BLOCKING CHECK';
EXEC sp_who2 'ACTIVE';
PRINT 'Look at SPID and BlkBy. A non-zero BlkBy indicates blocking.';
GO
