USE [XMT];
GO
DECLARE @SchemaName sysname=N'dbo', @TableName sysname=N'PFWIZREZ';
DECLARE @ObjectID int=OBJECT_ID(QUOTENAME(@SchemaName)+N'.'+QUOTENAME(@TableName));
IF @ObjectID IS NULL BEGIN RAISERROR('Target table not found.',16,1); RETURN; END;

SELECT s.name AS SchemaName,t.name AS TableName,t.object_id,SUM(p.rows) AS ApproxRows
FROM sys.tables t
JOIN sys.schemas s ON s.schema_id=t.schema_id
JOIN sys.partitions p ON p.object_id=t.object_id AND p.index_id IN (0,1)
WHERE t.object_id=@ObjectID
GROUP BY s.name,t.name,t.object_id;

SELECT i.index_id,i.name AS IndexName,i.type_desc,i.is_unique,i.is_primary_key,i.is_disabled
FROM sys.indexes i
WHERE i.object_id=@ObjectID
ORDER BY i.index_id;

SELECT c.column_id,c.name AS ColumnName,TYPE_NAME(c.user_type_id) AS DataType,
       c.max_length,c.precision,c.scale,c.is_nullable
FROM sys.columns c
WHERE c.object_id=@ObjectID
ORDER BY c.column_id;
GO
