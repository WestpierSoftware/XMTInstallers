USE [XMT];
GO
DECLARE @SPID int = NULL;  -- SET THIS
IF @SPID IS NULL BEGIN RAISERROR('Set @SPID first.',16,1); RETURN; END;

DBCC INPUTBUFFER(@SPID);

BEGIN TRY
    SELECT s.session_id,s.login_name,s.host_name,s.program_name,s.status,
           s.open_transaction_count,s.last_request_start_time,s.last_request_end_time,
           c.connect_time,c.client_net_address,c.net_transport
    FROM sys.dm_exec_sessions s
    LEFT JOIN sys.dm_exec_connections c ON c.session_id=s.session_id
    WHERE s.session_id=@SPID;
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER() AS ErrorNumber, ERROR_MESSAGE() AS ErrorMessage;
END CATCH;
GO
