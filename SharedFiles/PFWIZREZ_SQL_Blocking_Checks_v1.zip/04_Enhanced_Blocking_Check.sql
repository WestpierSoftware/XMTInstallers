USE [XMT];
GO
BEGIN TRY
    SELECT
        r.session_id AS WaitingSPID,
        r.blocking_session_id AS BlockingSPID,
        r.status,
        r.command,
        r.wait_type,
        r.wait_time AS WaitTimeMs,
        r.wait_resource,
        DB_NAME(r.database_id) AS DatabaseName,
        s.login_name,
        s.host_name,
        s.program_name,
        r.open_transaction_count,
        txt.text AS SQLText
    FROM sys.dm_exec_requests r
    JOIN sys.dm_exec_sessions s ON r.session_id=s.session_id
    OUTER APPLY sys.dm_exec_sql_text(r.sql_handle) txt
    WHERE r.database_id=DB_ID(N'XMT') OR r.blocking_session_id<>0
    ORDER BY CASE WHEN r.blocking_session_id<>0 THEN 0 ELSE 1 END,
             r.blocking_session_id DESC, r.session_id;
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER() AS ErrorNumber, ERROR_MESSAGE() AS ErrorMessage;
    PRINT 'Likely insufficient server-state permission. Use script 01 and give this script to DBA.';
END CATCH;
GO
