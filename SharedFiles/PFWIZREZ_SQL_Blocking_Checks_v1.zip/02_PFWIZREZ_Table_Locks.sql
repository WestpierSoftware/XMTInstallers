USE [XMT];
GO
DECLARE @SchemaName sysname=N'dbo', @TableName sysname=N'PFWIZREZ';
DECLARE @ObjectID int=OBJECT_ID(QUOTENAME(@SchemaName)+N'.'+QUOTENAME(@TableName));
IF @ObjectID IS NULL BEGIN RAISERROR('Target table not found.',16,1); RETURN; END;

SELECT
    tl.request_session_id AS SPID,
    tl.resource_type,
    tl.request_mode,
    tl.request_status,
    tl.resource_description
FROM sys.dm_tran_locks tl
LEFT JOIN sys.partitions p
  ON tl.resource_associated_entity_id=p.hobt_id
  OR tl.resource_associated_entity_id=p.partition_id
WHERE (tl.resource_type='OBJECT' AND tl.resource_associated_entity_id=@ObjectID)
   OR p.object_id=@ObjectID
ORDER BY tl.request_session_id, tl.request_status DESC, tl.resource_type, tl.request_mode;
GO
