REZSERVET MSI CLEANUP TOOLKIT v8
================================

PURPOSE
-------
Remove the OLD REZSERVET MSI installation and Windows service completely.

STOP when:
  - REZSERVET service = NOT INSTALLED
  - REZSERVET MSI registration = NONE

This toolkit DOES NOT install the new XmtRezServe MSI.

WHY v8
------
v7.1 successfully deleted the conflicting REZSERVET service, but then MSI
repair returned 1619.

The v7.1 log showed:
    Unblock-File: Cannot find drive. A drive with the name '2026-09-02 13'...

Root cause:
v7.1's Log function used Tee-Object. PowerShell functions return pipeline
output, so log lines polluted the Find-OldMsi return value. The variable that
should have contained one MSI path became an array containing timestamped log
lines plus the path. That corrupted the MSI argument passed to msiexec.

v8 fixes this by:
  - making logging output-free to the PowerShell pipeline
  - forcing the MSI path to one scalar string
  - validating Test-Path before calling msiexec
  - passing msiexec arguments as an argument array
  - understanding the current machine state where REZSERVET may already be gone

CURRENT EXPECTED STATE AFTER v7.1
---------------------------------
Old REZSERVET service:
    already deleted

Old REZSERVET MSI registration:
    still present

v8 should recognize that state automatically and continue with:
    repair old MSI
    verify service recreation
    stop old service
    uninstall old MSI
    verify service and MSI registration both gone

WHAT TO RUN
-----------
Run ONLY:

    RUN_AS_ADMIN.cmd

Do not manually run individual PowerShell commands.

LOGS
----
Logs\REZSERVET_CLEANUP_SUMMARY.log
Logs\REZSERVET_REPAIR.log
Logs\REZSERVET_UNINSTALL.log
Logs\REZSERVET_SERVICE_BEFORE_DELETE.txt

SUCCESS
-------
Expected final lines:

    SUCCESS: Old REZSERVET service and MSI registration removed completely.
    Old REZSERVET cleanup is complete. Stop here.

Only after this verified clean state should the NEW XmtRezServe MSI be tested
as a separate operation.
