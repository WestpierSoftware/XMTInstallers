﻿# REZSERVET MSI Cleanup Toolkit v8
# Run ONLY via RUN_AS_ADMIN.cmd.
#
# v8 fixes the v7.1 PowerShell pipeline bug that caused MSI path corruption
# and Windows Installer exit code 1619.
#
# Goal:
#   Completely remove the OLD REZSERVET MSI installation and service.
#   STOP when that state is verified.
#
# Current-state aware:
#   - If REZSERVET service is already gone but old MSI registration remains,
#     v8 continues from that state.
#   - If both are already gone, v8 reports SUCCESS and stops.
#   - If service still exists, v8 backs it up, stops it, deletes only the
#     conflicting service registration, then repairs/uninstalls the old MSI.

$ErrorActionPreference = 'Stop'

$BaseDir  = $PSScriptRoot
$ParentDir = Split-Path -Parent $BaseDir
$LogDir   = Join-Path $BaseDir 'Logs'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

$MainLog       = Join-Path $LogDir 'REZSERVET_CLEANUP_SUMMARY.log'
$RepairLog     = Join-Path $LogDir 'REZSERVET_REPAIR.log'
$UninstallLog  = Join-Path $LogDir 'REZSERVET_UNINSTALL.log'
$ServiceBackup = Join-Path $LogDir 'REZSERVET_SERVICE_BEFORE_DELETE.txt'

# IMPORTANT: Log MUST NOT emit pipeline output.
# v7.1 used Tee-Object, so calling a function that logged messages polluted
# the function's return value and corrupted the MSI path.
function Write-Log {
    param([Parameter(Mandatory=$true)][string]$Message)
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $Message"
    Write-Host $line
    Add-Content -LiteralPath $MainLog -Value $line -Encoding UTF8
}

function Get-RezServeRegistrations {
    $paths = @(
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    @(
        Get-ItemProperty -Path $paths -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -eq 'REZSERVET' } |
        Select-Object DisplayName, DisplayVersion, Publisher, PSChildName, UninstallString
    )
}

function Get-RezServeService {
    Get-Service -Name 'REZSERVET' -ErrorAction SilentlyContinue
}

function Find-OldMsi {
    $preferredName = 'RezServeTServiceSetup.msi'
    $preferredLocal = Join-Path $BaseDir $preferredName

    $candidates = @()

    if (Test-Path -LiteralPath $preferredLocal -PathType Leaf) {
        $candidates = @(Get-Item -LiteralPath $preferredLocal)
    }
    else {
        $candidates = @(
            Get-ChildItem -LiteralPath $ParentDir -Recurse -File -Filter $preferredName -ErrorAction SilentlyContinue
        )
    }

    if ($candidates.Count -eq 0) {
        $candidates = @(
            Get-ChildItem -LiteralPath $ParentDir -Recurse -File -Filter '*.msi' -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match 'RezServeT|REZSERVET|RezServe.*ServiceSetup' }
        )
    }

    $candidates = @($candidates | Sort-Object FullName -Unique)

    if ($candidates.Count -eq 0) {
        return $null
    }

    if ($candidates.Count -eq 1) {
        return [string]$candidates[0].FullName
    }

    $exact = @($candidates | Where-Object { $_.Name -ieq $preferredName })
    if ($exact.Count -eq 1) {
        return [string]$exact[0].FullName
    }

    $selected = $candidates |
        Sort-Object @{Expression={ [math]::Abs($_.Length - 970752) }}, LastWriteTime |
        Select-Object -First 1

    return [string]$selected.FullName
}

function Backup-ServiceState {
    Write-Log "Capturing REZSERVET service configuration..."
    "===== sc.exe qc REZSERVET =====" | Set-Content -LiteralPath $ServiceBackup -Encoding UTF8
    (& sc.exe qc REZSERVET 2>&1) | Add-Content -LiteralPath $ServiceBackup -Encoding UTF8
    "`r`n===== sc.exe queryex REZSERVET =====" | Add-Content -LiteralPath $ServiceBackup -Encoding UTF8
    (& sc.exe queryex REZSERVET 2>&1) | Add-Content -LiteralPath $ServiceBackup -Encoding UTF8
    "`r`n===== CIM service details =====" | Add-Content -LiteralPath $ServiceBackup -Encoding UTF8
    Get-CimInstance Win32_Service -Filter "Name='REZSERVET'" -ErrorAction SilentlyContinue |
        Select-Object Name,DisplayName,State,StartMode,PathName,StartName,ProcessId |
        Format-List | Out-String |
        Add-Content -LiteralPath $ServiceBackup -Encoding UTF8
    Write-Log "Service backup written: $ServiceBackup"
}

function Stop-RezServeSafely {
    $svc = Get-RezServeService
    if ($null -eq $svc) { return }

    if ($svc.Status -ne 'Stopped') {
        Write-Log "Stopping REZSERVET..."
        Stop-Service -Name 'REZSERVET' -Force
        (Get-Service -Name 'REZSERVET').WaitForStatus(
            'Stopped',
            [TimeSpan]::FromSeconds(30)
        )
        Write-Log "REZSERVET stopped."
    }
}

function Delete-RezServeServiceRegistration {
    if ($null -eq (Get-RezServeService)) {
        Write-Log "REZSERVET service registration is already absent."
        return
    }

    Backup-ServiceState
    Stop-RezServeSafely

    Write-Log "Deleting conflicting REZSERVET Windows service registration..."
    $out = & sc.exe delete REZSERVET 2>&1
    foreach ($line in $out) { Write-Log "sc delete: $line" }

    for ($i = 0; $i -lt 30; $i++) {
        Start-Sleep -Seconds 1
        if ($null -eq (Get-RezServeService)) {
            Write-Log "Confirmed: REZSERVET service registration is gone."
            return
        }
    }

    throw "REZSERVET is still registered after 30 seconds. Reboot may be required."
}

function Invoke-Msi {
    param(
        [Parameter(Mandatory=$true)][ValidateSet('Repair','Uninstall')][string]$Mode,
        [Parameter(Mandatory=$true)][string]$MsiPath,
        [Parameter(Mandatory=$true)][string]$LogPath
    )

    if ($Mode -eq 'Repair') {
        $args = @('/fa', $MsiPath, '/qn', '/norestart', '/L*V', $LogPath)
    }
    else {
        $args = @('/x', $MsiPath, '/qn', '/norestart', '/L*V', $LogPath)
    }

    $p = Start-Process -FilePath 'msiexec.exe' -ArgumentList $args -Wait -PassThru
    return [int]$p.ExitCode
}

try {
    Write-Log "============================================================"
    Write-Log "REZSERVET MSI Cleanup Toolkit v8"
    Write-Log "BaseDir=$BaseDir"
    Write-Log "ParentDir=$ParentDir"
    Write-Log "Goal=Remove OLD REZSERVET completely; then STOP"
    Write-Log "============================================================"

    $regs = @(Get-RezServeRegistrations)
    $svc  = Get-RezServeService

    if ($regs.Count -eq 0 -and $null -eq $svc) {
        Write-Log "SUCCESS: Old REZSERVET service and MSI registration are already absent."
        Write-Log "Old REZSERVET cleanup is complete. Stop here."
        exit 0
    }

    if ($regs.Count -gt 0) {
        foreach ($r in $regs) {
            Write-Log "MSI before: Name=$($r.DisplayName) Version=$($r.DisplayVersion) ProductCode=$($r.PSChildName)"
        }
    }
    else {
        Write-Log "MSI before: no REZSERVET product registration found."
    }

    if ($null -ne $svc) {
        Write-Log "Service before cleanup: $($svc.Status)"
    }
    else {
        Write-Log "Service before cleanup: NOT_INSTALLED"
    }

    # If MSI registration remains, we need the original MSI to repair/uninstall it.
    if ($regs.Count -gt 0) {
        $Msi = Find-OldMsi

        if ([string]::IsNullOrWhiteSpace($Msi)) {
            throw "Could not locate the original RezServeTServiceSetup.msi beneath $ParentDir"
        }

        # Force scalar string and validate before any MSI action.
        $Msi = [string]$Msi
        Write-Log "MSI selected: $Msi"

        if (-not (Test-Path -LiteralPath $Msi -PathType Leaf)) {
            throw "Selected MSI path does not exist: $Msi"
        }

        $item = Get-Item -LiteralPath $Msi
        Write-Log "MSI_Size=$($item.Length)"
        Write-Log "MSI_LastWrite=$($item.LastWriteTime)"

        try {
            Unblock-File -LiteralPath $Msi -ErrorAction Stop
            Write-Log "MSI unblocked/checked."
        }
        catch {
            Write-Log "WARNING: Unblock-File failed but MSI path is valid: $($_.Exception.Message)"
        }

        # Remove stale/conflicting service only if it still exists.
        Delete-RezServeServiceRegistration

        # Current expected v7.1 state reaches here with service already absent.
        Write-Log "Starting OLD MSI repair..."
        $repairRC = Invoke-Msi -Mode Repair -MsiPath $Msi -LogPath $RepairLog
        Write-Log "Repair exit code: $repairRC"
        Write-Log "Repair log: $RepairLog"

        if ($repairRC -notin @(0,3010)) {
            throw "OLD MSI repair failed with exit code $repairRC. Uninstall NOT attempted."
        }

        $svcAfterRepair = Get-RezServeService
        if ($null -eq $svcAfterRepair) {
            throw "OLD MSI repair reported success but REZSERVET service was not recreated. Uninstall NOT attempted."
        }

        Write-Log "Repair recreated REZSERVET service. State=$($svcAfterRepair.Status)"
        Stop-RezServeSafely

        Write-Log "Starting OLD MSI uninstall..."
        $uninstallRC = Invoke-Msi -Mode Uninstall -MsiPath $Msi -LogPath $UninstallLog
        Write-Log "Uninstall exit code: $uninstallRC"
        Write-Log "Uninstall log: $UninstallLog"

        if ($uninstallRC -notin @(0,1605,3010)) {
            throw "OLD MSI uninstall failed with exit code $uninstallRC."
        }
    }
    else {
        # No MSI registration remains. If a stale service is still present,
        # remove only that stale service registration after backing it up.
        Delete-RezServeServiceRegistration
    }

    Start-Sleep -Seconds 2

    $finalRegs = @(Get-RezServeRegistrations)
    $finalSvc  = Get-RezServeService

    if ($null -eq $finalSvc) {
        Write-Log "Final service state: NOT_INSTALLED"
    }
    else {
        Write-Log "Final service state: $($finalSvc.Status)"
    }

    if ($finalRegs.Count -eq 0) {
        Write-Log "Final MSI registration: NONE"
    }
    else {
        foreach ($r in $finalRegs) {
            Write-Log "MSI remains: Name=$($r.DisplayName) Version=$($r.DisplayVersion) ProductCode=$($r.PSChildName)"
        }
    }

    if ($null -eq $finalSvc -and $finalRegs.Count -eq 0) {
        Write-Log "SUCCESS: Old REZSERVET service and MSI registration removed completely."
        Write-Log "Old REZSERVET cleanup is complete. Stop here."
        exit 0
    }

    throw "Cleanup verification failed. Do NOT install XmtRezServe yet."
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)"
    Write-Log "STOPPED SAFELY. Do not repeatedly rerun until this new error is reviewed."
    exit 30
}
