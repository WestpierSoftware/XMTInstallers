@echo off
setlocal
cd /d "%~dp0"

net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell.exe -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo Unblocking toolkit PowerShell files...
powershell.exe -NoProfile -Command "Get-ChildItem -LiteralPath '%~dp0' -Filter '*.ps1' -File | Unblock-File -ErrorAction SilentlyContinue"

echo Starting REZSERVET Cleanup Toolkit v8...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0REZSERVET_CLEANUP_AUTO.ps1"

set RC=%ERRORLEVEL%
echo.
echo Exit code: %RC%
echo.
echo Summary:
echo   %~dp0Logs\REZSERVET_CLEANUP_SUMMARY.log
echo.
pause
exit /b %RC%
