@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -Command "Unblock-File -LiteralPath '%~dp0CHECK_REZSERVET_STATE.ps1' -ErrorAction SilentlyContinue"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CHECK_REZSERVET_STATE.ps1"
pause
