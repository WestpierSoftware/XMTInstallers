﻿$ErrorActionPreference = 'SilentlyContinue'

Write-Host "===== REZSERVET service ====="
$svc = Get-Service -Name 'REZSERVET'
if ($null -eq $svc) {
    Write-Host "NOT INSTALLED"
} else {
    sc.exe query REZSERVET
    sc.exe qc REZSERVET
}

Write-Host ""
Write-Host "===== REZSERVET MSI registration ====="
$paths = @(
 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
 'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
)
$items = @(
 Get-ItemProperty -Path $paths -ErrorAction SilentlyContinue |
 Where-Object { $_.DisplayName -eq 'REZSERVET' } |
 Select-Object DisplayName,DisplayVersion,Publisher,PSChildName,UninstallString
)
if ($items.Count -eq 0) {
    Write-Host "NONE"
} else {
    $items | Format-List
}
