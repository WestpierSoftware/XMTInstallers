REZSERVET MSI CLEANUP TOOLKIT v9
================================

PURPOSE
-------
Completely remove the OLD REZSERVET MSI installation and Windows service.

This toolkit does NOT install the NEW XmtRezServe MSI.

WHY v9
------
v8 correctly identified the current machine state:

  REZSERVET Windows service: NOT INSTALLED
  old REZSERVET MSI registration: PRESENT
  correct old MSI: FOUND

However, Windows Installer returned 1639 and displayed the msiexec usage/help
window.

That means msiexec rejected the command line.

v9 fixes ONLY that part:
  - retains the state-aware v8 logic
  - does NOT try to delete REZSERVET again if it is already absent
  - builds ONE explicitly quoted msiexec argument string
  - logs the exact msiexec argument string before execution
  - validates the MSI path before repair
  - stops safely if repair or uninstall fails

EXPECTED CURRENT FLOW
---------------------
1. Detect old MSI registration.
2. Detect REZSERVET service already absent.
3. Locate original RezServeTServiceSetup.msi.
4. Run OLD MSI repair with correctly quoted command line.
5. Verify repair recreated REZSERVET.
6. Stop REZSERVET if necessary.
7. Run OLD MSI uninstall.
8. Verify:
      REZSERVET service = NOT INSTALLED
      REZSERVET MSI registration = NONE
9. STOP.

WHAT TO RUN
-----------
Run ONLY:

    RUN_AS_ADMIN.cmd

LOGS
----
Logs\REZSERVET_CLEANUP_SUMMARY.log
Logs\REZSERVET_REPAIR.log
Logs\REZSERVET_UNINSTALL.log

SUCCESS
-------
Expected final lines:

    SUCCESS: Old REZSERVET service and MSI registration removed completely.
    Old REZSERVET cleanup is complete. Stop here.

Do not test the NEW XmtRezServe MSI until this success state is reached.
