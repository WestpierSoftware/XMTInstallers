
from generate_synthetic_imf import build_file

def test_count():
    text, stats = build_file(5, seed=1, divider="dashes")
    assert text.count("/ACT") == 5
    assert stats["corrupted"] == 0

def test_markers_on():
    text, _ = build_file(50, seed=2, test_markers=True)
    assert "NAMTESTNAME " in text
    assert "AD1TESTAD1 " in text or "AD2TESTAD2 " in text or "AD3TESTAD3 " in text

def test_markers_off():
    text, _ = build_file(50, seed=2, test_markers=False)
    assert "NAMTESTNAME " not in text
    assert "AD1TESTAD1 " not in text
    assert "AD2TESTAD2 " not in text
    assert "AD3TESTAD3 " not in text

def test_imfsplitter_headers():
    text, _ = build_file(3, seed=3, pul="CDG", divider="imfsplitter")
    assert text.count("MODE=PUL ACTION=MOVE") == 3
    assert text.count("PUL=CDG") >= 3

def test_corruption_100_percent():
    text, stats = build_file(20, seed=4, corrupt_percent=100)
    assert stats["corrupted"] == 20

def test_embed_act_100_percent():
    text, stats = build_file(20, seed=5, embed_tag="ACT", embed_percent=100)
    assert stats["embedded"] == 20
    assert text.count("/ACT") > 20

def test_repeatable():
    a, sa = build_file(
        10, seed=999,
        corrupt_percent=30,
        embed_tag="ACT",
        embed_percent=40,
        test_markers=True
    )
    b, sb = build_file(
        10, seed=999,
        corrupt_percent=30,
        embed_tag="ACT",
        embed_percent=40,
        test_markers=True
    )
    assert a == b
    assert sa == sb
