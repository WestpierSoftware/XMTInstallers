XMT SYNTHETIC IMF/RES GENERATOR v1.2
====================================

PURPOSE
-------
This package generates completely synthetic XMT-style IMF/RES text files for:

- normal functional testing
- routing testing
- repeatable regression testing
- load testing
- parser robustness testing
- deliberate malformed/corrupt reservation testing
- embedded-tag testing

It does NOT read production/customer data.
It does NOT connect to SQL Server.
It does NOT write to XMT database tables.
It does NOT automatically place files in live XMT input folders.

PACKAGE CONTENTS
----------------
generate_synthetic_imf.py
    Main generator program.

test_generate_synthetic_imf.py
    Optional pytest test suite.

README_FIRST.txt
    This guide.

SAMPLE_TestMarkers_ON.RES
    Example generated output with visible TEST markers enabled.

SAMPLE_TestMarkers_OFF.RES
    Example generated output with visible TEST markers disabled.


QUICK START
-----------
Generate 10 normal synthetic reservations:

    python .\generate_synthetic_imf.py

This creates:

    SYNTHETIC_IMF.RES

Generate 100 normal synthetic reservations:

    python .\generate_synthetic_imf.py -n 100

Generate 100 reservations to a specific output file:

    python .\generate_synthetic_imf.py -n 100 -o .\Normal100.RES


IMPORTANT: OUTPUT FILES
-----------------------
Use -o or --output to choose a DIFFERENT filename for every scenario.

Examples:

    python .\generate_synthetic_imf.py -n 100 -o .\Normal100.RES

    python .\generate_synthetic_imf.py -n 100 --divider imfsplitter ^
        -o .\IMFSplitter100.RES

    python .\generate_synthetic_imf.py -n 100 --seed 12345 ^
        --corrupt-percent 10 -o .\Corrupt10Percent.RES

If -o is omitted, the default file is always:

    SYNTHETIC_IMF.RES

Therefore a later run can overwrite the previous SYNTHETIC_IMF.RES.
For test suites, always give each scenario its own -o filename.


ALL PARAMETERS
--------------
-h, --help
    Show command-line help.

-n N
--count N
    Number of synthetic reservations to create.

    Default:
        10

    Allowed:
        1 to 100000

Example:

    python .\generate_synthetic_imf.py -n 500 -o .\Synthetic500.RES


-o FILE
--output FILE
    Output filename.

Default:

    SYNTHETIC_IMF.RES

Examples:

    python .\generate_synthetic_imf.py -n 10 -o .\TestA.RES

    python .\generate_synthetic_imf.py -n 10 -o C:\temp\XMT\TestB.RES


--seed N
    Use a fixed random seed.

    Same seed + same parameters gives the same generated data.

This is useful for regression testing because the same test dataset can be
regenerated later.

Example:

    python .\generate_synthetic_imf.py -n 100 --seed 12345 ^
        -o .\Regression_Seed12345.RES

Generate it again using exactly the same command and the synthetic reservation
content will be repeatable.

For random data each run, omit --seed.


--pul mixed|LIS|CDG|TIA
    Controls routing/PUL values in generated reservations.

Default:

    mixed

Examples:

Mixed:

    python .\generate_synthetic_imf.py -n 100 --pul mixed ^
        -o .\Mixed100.RES

LIS only:

    python .\generate_synthetic_imf.py -n 50 --pul LIS ^
        -o .\LIS50.RES

CDG only:

    python .\generate_synthetic_imf.py -n 50 --pul CDG ^
        -o .\CDG50.RES

TIA only:

    python .\generate_synthetic_imf.py -n 50 --pul TIA ^
        -o .\TIA50.RES


ROUTING RELATIONSHIPS
---------------------
The generator keeps these synthetic routing fields coherent:

LIS
    PUL = LIS
    CTO = LISAA
    CTI = LISAA
    DOL = LIS

CDG
    PUL = CDG
    CTO = CDGAA
    CTI = CDGAA
    DOL = CDG

TIA
    PUL = TIA
    CTO = TIAAA
    CTI = TIAAA
    DOL = TIA


--divider none|dashes|filelink|imfsplitter
    Controls how reservations are separated/presented in the output file.

Default:

    dashes


DIVIDER: dashes
---------------
A line of dashes is placed around/between reservations.

Example:

    python .\generate_synthetic_imf.py -n 20 --divider dashes ^
        -o .\Dashes20.RES


DIVIDER: filelink
-----------------
Produces the FileLink-style dashed reservation separation used for visual/log
testing.

Example:

    python .\generate_synthetic_imf.py -n 20 --divider filelink ^
        -o .\FileLinkStyle20.RES


DIVIDER: imfsplitter
--------------------
Places an IMFSplitter-style log/header line before each reservation.

The generated header contains synthetic values similar to:

    ===== 2026-09-05 00:25:12 FILE=AOR631220260905002512001.RES
    MODE=PUL ACTION=MOVE INPUT=1 PUL_OCCURRENCES=1 PUL=CDG
    ROUTE=SQL AS400OUT=False SQLOUT=True SQLMODE=SQL =====

Example:

    python .\generate_synthetic_imf.py -n 20 --divider imfsplitter ^
        -o .\IMFSplitterStyle20.RES


DIVIDER: none
-------------
No divider/header is inserted between generated reservations.

Example:

    python .\generate_synthetic_imf.py -n 20 --divider none ^
        -o .\NoDivider20.RES


TEST MARKERS
------------
Visible synthetic markers are ON by default.

With markers ON, generated fields include values such as:

    /NAMTESTNAME ASHBROOK,ALDEN\/
    /AD1TESTAD1 101 TESTWOOD AVENUE\/
    /AD2TESTAD2 SAMPLETON\/
    /AD3TESTAD3 TEST COUNTY\/

Other synthetic markers include:

    CNF starts 4444
    CID starts VI44
    CON starts 444
    BCD starts 444
    DLC starts VI4

Dates such as PUD/DOD/DOB use day 11 as an additional visible TEST convention.


--test-markers
--------------
Explicitly switch visible TEST markers ON.

Example:

    python .\generate_synthetic_imf.py -n 100 --test-markers ^
        -o .\MarkersON100.RES


--no-test-markers
-----------------
Switch TESTNAME and TESTAD1/2/3 markers OFF.

Example:

    python .\generate_synthetic_imf.py -n 100 --no-test-markers ^
        -o .\MarkersOFF100.RES

This makes the synthetic data visually closer to ordinary reservation data,
while still remaining generated data.


--minimal
---------
Generate a smaller/core reservation field set.

This reduces optional fields such as addresses, DOB and some optional tags.

Example:

    python .\generate_synthetic_imf.py -n 100 --minimal ^
        -o .\Minimal100.RES


--no-con
--------
Do not generate CON.

Example:

    python .\generate_synthetic_imf.py -n 100 --no-con ^
        -o .\NoCON100.RES


--no-bcd
--------
Do not generate BCD.

Example:

    python .\generate_synthetic_imf.py -n 100 --no-bcd ^
        -o .\NoBCD100.RES


--no-dlc
--------
Do not generate DLC.

Example:

    python .\generate_synthetic_imf.py -n 100 --no-dlc ^
        -o .\NoDLC100.RES


CORRUPTION TESTING
==================

--corrupt-percent N
-------------------
Deliberately corrupt approximately N percent of generated reservations.

Default:

    0

Therefore corruption is OFF unless requested.

Example: approximately 10% corruption:

    python .\generate_synthetic_imf.py -n 100 --seed 12345 ^
        --corrupt-percent 10 ^
        -o .\Corrupt10Percent.RES

The percentage is probabilistic.

Therefore:

    --count 100 --corrupt-percent 10

does NOT guarantee exactly 10 corrupted reservations.

For example it could produce 8, 10, 13, etc.

Using --seed makes the selected corrupted records and corruption types
repeatable.


CURRENT CORRUPTION TYPES
------------------------
The program randomly chooses from these deliberate faults:

1. bad_date
   Replaces a PUD, DOD or DOB date portion with an invalid date such as:

       99XXX99

2. bad_tag
   Corrupts a known tag name.

3. drop_delimiter
   Removes a \/ delimiter.

4. truncate
   Removes part of the end of the reservation.

5. insert_noise
   Inserts:

       @@CORRUPT@@

   into the reservation text.


CORRUPTION REPORT
-----------------
After generation the program reports the actual result.

Example:

    Synthetic reservations written: 100
    Corrupted records: 13
    Corruption breakdown:
      bad_date: 6
      bad_tag: 2
      drop_delimiter: 3
      truncate: 2

This is useful because the requested percentage is approximate.


100% CORRUPTION TEST
--------------------
Every generated reservation is selected for corruption:

    python .\generate_synthetic_imf.py -n 100 --seed 12345 ^
        --corrupt-percent 100 ^
        -o .\AllCorrupt100.RES


LOW CORRUPTION TEST
-------------------
Approximately 1%:

    python .\generate_synthetic_imf.py -n 1000 --seed 12345 ^
        --corrupt-percent 1 ^
        -o .\Corrupt1Percent1000.RES


EMBEDDED TAG TESTING
====================

--embed-tag TAG
---------------
Deliberately inserts a tag-like token inside the VALUE of another valid tag.

This is intended to test parsers that incorrectly treat tag-like text inside
a value as a genuine new tag.

Example:

    --embed-tag ACT

might conceptually produce something like:

    /NAMTESTNAME ASH/ACTBROOK,ALDEN\/

The outer NAM tag still exists, but /ACT appears inside its value.


--embed-percent N
-----------------
Controls approximately what percentage of reservations receive the embedded tag.

Both switches are normally used together.


EMBED /ACT IN 10%
-----------------
Example:

    python .\generate_synthetic_imf.py -n 100 --seed 12345 ^
        --embed-tag ACT --embed-percent 10 ^
        -o .\EmbeddedACT10Percent.RES


EMBED /PUL IN 10%
-----------------
Example:

    python .\generate_synthetic_imf.py -n 100 --seed 12345 ^
        --embed-tag PUL --embed-percent 10 ^
        -o .\EmbeddedPUL10Percent.RES


EMBED /CNF IN 25%
-----------------
Example:

    python .\generate_synthetic_imf.py -n 100 --seed 12345 ^
        --embed-tag CNF --embed-percent 25 ^
        -o .\EmbeddedCNF25Percent.RES


EMBED TAG IN EVERY RECORD
-------------------------
Example:

    python .\generate_synthetic_imf.py -n 100 --seed 12345 ^
        --embed-tag ACT --embed-percent 100 ^
        -o .\EmbeddedACT100Percent.RES


EMBEDDED-TAG REPORT
-------------------
After generation:

    Embedded-tag records: 11

Again, percentages are probabilistic unless set to 100.


COMBINING CORRUPTION AND EMBEDDED TAGS
======================================
These can be used together.

Example:

    python .\generate_synthetic_imf.py -n 1000 ^
        --seed 20260905 ^
        --corrupt-percent 5 ^
        --embed-tag ACT ^
        --embed-percent 5 ^
        -o .\Corrupt5_EmbeddedACT5_1000.RES

Some reservations may receive corruption, some an embedded tag, and some can
receive both.


FULL PARSER-STRESS EXAMPLE
--------------------------
PowerShell multi-line form:

    python .\generate_synthetic_imf.py `
        -n 1000 `
        --seed 20260905 `
        --divider imfsplitter `
        --corrupt-percent 5 `
        --embed-tag ACT `
        --embed-percent 5 `
        --test-markers `
        -o .\ParserStress1000.RES

Single-line form:

    python .\generate_synthetic_imf.py -n 1000 --seed 20260905 --divider imfsplitter --corrupt-percent 5 --embed-tag ACT --embed-percent 5 --test-markers -o .\ParserStress1000.RES


EXAMPLE TEST SUITE WITH DIFFERENT OUTPUT FILES
==============================================
The following commands deliberately produce separate files so results can be
retained and compared.

1. Normal mixed dataset

    python .\generate_synthetic_imf.py -n 100 --seed 1001 ^
        -o .\01_Normal_Mixed100.RES

2. LIS routing only

    python .\generate_synthetic_imf.py -n 100 --seed 1002 --pul LIS ^
        -o .\02_LIS100.RES

3. CDG routing only

    python .\generate_synthetic_imf.py -n 100 --seed 1003 --pul CDG ^
        -o .\03_CDG100.RES

4. TIA routing only

    python .\generate_synthetic_imf.py -n 100 --seed 1004 --pul TIA ^
        -o .\04_TIA100.RES

5. FileLink-style separation

    python .\generate_synthetic_imf.py -n 100 --seed 1005 ^
        --divider filelink ^
        -o .\05_FileLinkStyle100.RES

6. IMFSplitter-style headers

    python .\generate_synthetic_imf.py -n 100 --seed 1006 ^
        --divider imfsplitter ^
        -o .\06_IMFSplitterStyle100.RES

7. No divider

    python .\generate_synthetic_imf.py -n 100 --seed 1007 ^
        --divider none ^
        -o .\07_NoDivider100.RES

8. TEST markers OFF

    python .\generate_synthetic_imf.py -n 100 --seed 1008 ^
        --no-test-markers ^
        -o .\08_NoTestMarkers100.RES

9. Minimal records

    python .\generate_synthetic_imf.py -n 100 --seed 1009 ^
        --minimal ^
        -o .\09_Minimal100.RES

10. No CON

    python .\generate_synthetic_imf.py -n 100 --seed 1010 ^
        --no-con ^
        -o .\10_NoCON100.RES

11. No BCD

    python .\generate_synthetic_imf.py -n 100 --seed 1011 ^
        --no-bcd ^
        -o .\11_NoBCD100.RES

12. No DLC

    python .\generate_synthetic_imf.py -n 100 --seed 1012 ^
        --no-dlc ^
        -o .\12_NoDLC100.RES

13. 10% corruption

    python .\generate_synthetic_imf.py -n 100 --seed 1013 ^
        --corrupt-percent 10 ^
        -o .\13_Corrupt10Percent100.RES

14. 25% corruption

    python .\generate_synthetic_imf.py -n 100 --seed 1014 ^
        --corrupt-percent 25 ^
        -o .\14_Corrupt25Percent100.RES

15. Embedded ACT in about 10%

    python .\generate_synthetic_imf.py -n 100 --seed 1015 ^
        --embed-tag ACT --embed-percent 10 ^
        -o .\15_EmbeddedACT10Percent100.RES

16. Embedded PUL in about 10%

    python .\generate_synthetic_imf.py -n 100 --seed 1016 ^
        --embed-tag PUL --embed-percent 10 ^
        -o .\16_EmbeddedPUL10Percent100.RES

17. Combined parser stress

    python .\generate_synthetic_imf.py -n 1000 --seed 1017 ^
        --divider imfsplitter ^
        --corrupt-percent 5 ^
        --embed-tag ACT --embed-percent 5 ^
        -o .\17_ParserStress1000.RES

18. Load test

    python .\generate_synthetic_imf.py -n 10000 --seed 1018 ^
        -o .\18_LoadTest10000.RES


REPEATABLE REGRESSION RECOMMENDATION
====================================
For comparison between Python XmtRezServe and C# XmtRezServe, use a fixed seed
and keep the generated source file.

Example:

    python .\generate_synthetic_imf.py -n 1000 ^
        --seed 20260905 ^
        --divider dashes ^
        -o .\XMT_Regression_20260905_1000.RES

The same generated file can then be copied into each TEST path, allowing both
implementations to receive equivalent synthetic reservation data.


USER-EDITABLE DEFAULTS IN THE .PY
=================================
Near the top of generate_synthetic_imf.py:

    DEFAULT_COUNT = 10
    DEFAULT_OUTPUT = "SYNTHETIC_IMF.RES"
    DEFAULT_PUL = "mixed"
    DEFAULT_DIVIDER = "dashes"
    DEFAULT_CORRUPT_PERCENT = 0.0
    DEFAULT_EMBED_TAG = ""
    DEFAULT_EMBED_PERCENT = 0.0
    DEFAULT_TEST_MARKERS = True
    DEFAULT_SEED = None

Examples of changing defaults in the Python file:

Always generate 100 records by default:

    DEFAULT_COUNT = 100

Make IMFSplitter headers the default:

    DEFAULT_DIVIDER = "imfsplitter"

Turn normal corruption on by default at 5%:

    DEFAULT_CORRUPT_PERCENT = 5.0

Turn embedded ACT tests on by default:

    DEFAULT_EMBED_TAG = "ACT"
    DEFAULT_EMBED_PERCENT = 5.0

Turn visible TESTNAME / TESTAD markers off by default:

    DEFAULT_TEST_MARKERS = False

IMPORTANT:
Command-line values override these defaults.


SYNTHETIC FIELD CONTENT
=======================
Typical generated fields include:

ACT
CNF
NAM
PUL
CTO
PUD
DOL
CTI
DOD
CAR
VTP
RAT
BCD
FLT
CID
CON
DLC
AD1
AD2
AD3
DOB
AGE
RAP
SORT
MOP
CUR

Not every optional field appears in every generated reservation.


DATES
-----
PUD is generated as a future synthetic date.

DOD is generated after PUD.

Visible test day 11 is used in normal generated date values.

With deliberate bad-date corruption, an invalid value such as 99XXX99 may be
inserted.


PROGRAM OUTPUT SUMMARY
======================
After each run the program reports:

    Synthetic reservations written
    Output file
    PUL mode
    Divider style
    Seed
    Test markers ON/OFF
    Corrupted records
    Embedded-tag records

If corruption was generated it also reports the corruption breakdown.


CHECK COMMAND-LINE HELP
=======================
At any time:

    python .\generate_synthetic_imf.py --help


OPTIONAL PYTEST TEST SUITE
==========================
The generator itself requires only Python standard libraries.

If pytest is installed:

    pytest .\test_generate_synthetic_imf.py


RECOMMENDED SAFE WORKFLOW
=========================
1. Generate files in a temporary/test working directory.

2. Give every scenario a meaningful output filename using -o.

3. Open and visually inspect a small sample before XMT processing.

4. Keep TEST markers ON for normal testing.

5. Use --seed for reproducible comparison/regression tests.

6. Use corruption and embedded-tag features only for deliberate error handling
   and parser robustness tests.

7. Do not point the generator directly at a live production input directory.

8. Keep normal synthetic datasets separate from deliberately corrupted datasets.

9. Record the exact command/seed used when a generated case exposes a defect.

10. Re-run the same seed and parameters to reproduce the condition.


SUGGESTED FIRST TESTS
=====================
A useful initial progression is:

A. 10 clean records
    python .\generate_synthetic_imf.py -n 10 --seed 1 ^
        -o .\A_Clean10.RES

B. 100 clean records
    python .\generate_synthetic_imf.py -n 100 --seed 2 ^
        -o .\B_Clean100.RES

C. 100 mixed with IMFSplitter headers
    python .\generate_synthetic_imf.py -n 100 --seed 3 ^
        --divider imfsplitter ^
        -o .\C_IMFSplitter100.RES

D. 100 with 10% corruption
    python .\generate_synthetic_imf.py -n 100 --seed 4 ^
        --corrupt-percent 10 ^
        -o .\D_Corrupt10Percent.RES

E. 100 with embedded ACT
    python .\generate_synthetic_imf.py -n 100 --seed 5 ^
        --embed-tag ACT --embed-percent 10 ^
        -o .\E_EmbeddedACT.RES

F. 1000 clean load/regression test
    python .\generate_synthetic_imf.py -n 1000 --seed 6 ^
        -o .\F_Clean1000.RES

G. 1000 parser stress
    python .\generate_synthetic_imf.py -n 1000 --seed 7 ^
        --corrupt-percent 5 ^
        --embed-tag ACT --embed-percent 5 ^
        -o .\G_ParserStress1000.RES


VERSION
-------
XMT Synthetic IMF/RES Generator v1.2

README revision:
Comprehensive v1.1/v1.2 feature and usage guide.
