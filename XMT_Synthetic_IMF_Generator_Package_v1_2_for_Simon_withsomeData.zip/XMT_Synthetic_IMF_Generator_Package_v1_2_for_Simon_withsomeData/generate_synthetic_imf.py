
from pathlib import Path
import argparse
import random
import string
from datetime import datetime, timedelta

# ---------------------------------------------------------------------------
# USER-EDITABLE DEFAULTS
# Command-line switches override these defaults.
# ---------------------------------------------------------------------------
DEFAULT_COUNT = 10
DEFAULT_OUTPUT = "SYNTHETIC_IMF.RES"
DEFAULT_PUL = "mixed"                  # mixed | LIS | CDG | TIA
DEFAULT_DIVIDER = "dashes"             # none | dashes | filelink | imfsplitter
DEFAULT_CORRUPT_PERCENT = 0.0           # 0 = OFF
DEFAULT_EMBED_TAG = ""                  # "" = OFF; e.g. ACT, CNF, NAM, PUL
DEFAULT_EMBED_PERCENT = 0.0             # 0 = OFF
DEFAULT_TEST_MARKERS = True             # visible TESTNAME / TESTAD1/2/3 markers
DEFAULT_SEED = None

ROUTES = {
    "LIS": ("LISAA", "LISAA", "LIS"),
    "CDG": ("CDGAA", "CDGAA", "CDG"),
    "TIA": ("TIAAA", "TIAAA", "TIA"),
}

FIRST = ["ALDEN","BERIA","CALEN","DAVIN","ELMARA","FISON","GALIA","HAREN","JOTIN","KANIA"]
LAST  = ["ASHBROOK","BELFORD","CARFIELD","DALLEY","ELMMORE","FENSTONE","GARWELL","HALWOOD"]
ACTS  = ["CR","MR","XL"]
VTPS  = ["CDAR","FVAR","IDAR","IFMR","EDAR","CDAE"]
RATS  = ["SVI","2CI","VNI","Y4I","NHE","5XZ","1AE"]
MOPS  = ["CA","TP"]
CARS  = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")

KNOWN_TAGS = [
    "ACT","CNF","NAM","PUL","CTO","PUD","DOL","CTI","DOD","CAR","VTP","RAT",
    "BCD","FLT","CID","CON","DLC","AD1","AD2","AD3","DOB","AGE","RAP","SORT","MOP","CUR"
]

CORRUPTION_TYPES = (
    "truncate",
    "drop_delimiter",
    "bad_tag",
    "bad_date",
    "insert_noise",
)

def digits(rng, n):
    return "".join(rng.choice(string.digits) for _ in range(n))

def alnum(rng, n):
    chars = string.ascii_uppercase + string.digits
    return "".join(rng.choice(chars) for _ in range(n))

def synthetic_filename(rng, index):
    stamp = datetime.now().strftime("%Y%m%d%H%M%S")
    return f"AOR{rng.randint(1000,9999)}{stamp}{index:03d}.RES"

def make_name(rng, test_markers=True):
    prefix = "TESTNAME " if test_markers else ""
    return f"{prefix}{rng.choice(LAST)},{rng.choice(FIRST)}"

def make_record(rng, pul, minimal=False, include_con=True, include_bcd=True,
                include_dlc=True, test_markers=True):
    cto, cti, dol = ROUTES[pul]
    start = datetime.now().replace(second=0, microsecond=0) + timedelta(days=rng.randint(1,90))
    end = start + timedelta(days=rng.randint(1,14))

    p = [
        f"/ACT{rng.choice(ACTS)}\\/",
        f"CNF4444{digits(rng,4)}{rng.choice(string.ascii_uppercase)}{digits(rng,1)}\\/",
        f"NAM{make_name(rng, test_markers)}\\/",
        f"PUL{pul}\\/",
        f"CTO{cto}\\/",
        f"PUD11{start.strftime('%b%y').upper()}/{rng.choice(['0800','0900','1200','1600','1800'])}\\/",
        f"DOL{dol}\\/",
        f"CTI{cti}\\/",
        f"DOD11{end.strftime('%b%y').upper()}/{rng.choice(['0900','1200','1600','1700','1930'])}\\/",
        f"CAR{rng.choice(CARS)}\\/",
        f"VTP{rng.choice(VTPS)}\\/",
        f"RAT{rng.choice(RATS)}\\/",
    ]

    if include_bcd:
        p.append(f"BCD444{digits(rng,4)}\\/")
    if rng.random() < 0.7:
        p.append(f"FLT{rng.choice(string.ascii_uppercase)}{digits(rng,5)}\\/")
    p.append(
        f"CIDVI44{digits(rng,12)}"
        f"{rng.choice(string.ascii_uppercase)}{rng.choice(string.ascii_uppercase)}"
        f"{digits(rng,8)}\\/"
    )
    if include_con:
        p.append(f"CON444{digits(rng,7)}\\/")
    if include_dlc and rng.random() < 0.35:
        p.append(f"DLCVI4{alnum(rng,17)}\\/")

    if not minimal:
        if rng.random() < 0.55:
            if test_markers:
                p.append("AD1TESTAD1 101 TESTWOOD AVENUE\\/")
                if rng.random() < 0.6:
                    p.append("AD2TESTAD2 SAMPLETON\\/")
                if rng.random() < 0.6:
                    p.append("AD3TESTAD3 TEST COUNTY\\/")
            else:
                p.append("AD1101 TESTWOOD AVENUE\\/")
                if rng.random() < 0.6:
                    p.append("AD2SAMPLETON\\/")
                if rng.random() < 0.6:
                    p.append("AD3TEST COUNTY\\/")

        if rng.random() < 0.65:
            p.append(
                f"DOB11{rng.choice(['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'])}"
                f"{rng.randint(45,99):02d}\\/"
            )
        if rng.random() < 0.3:
            p.append(f"AGE{rng.randint(18,90)}\\/")
        if rng.random() < 0.3:
            p.append(f"RAP{alnum(rng,7)}\\/")
        if rng.random() < 0.3:
            p.append(f"SORT{digits(rng,8)}/P/{rng.choice(['AA','YB','CC'])}\\/")

    p.append(f"MOP{rng.choice(MOPS)}\\/")
    p.append("CUREUR\\/")
    return "".join(p)

def embed_tag_inside_valid_value(record, rng, tag_name):
    r"""
    Intentionally embeds text such as '/ACT' inside the VALUE of an existing
    otherwise-valid tag for parser robustness testing.

    Example concept:
        /NAMTESTPERSON\/
      ->/NAMTEST/ACTPERSON\/
    """
    tag_name = tag_name.upper()
    candidates = ["NAM","AD1","AD2","AD3","RAP","FLT","CON","DLC","CID","CNF"]
    found = []

    for tag in candidates:
        pos = record.find(tag)
        if pos >= 0:
            end = record.find("\\/", pos)
            if end > pos + len(tag) + 1:
                found.append((tag, pos, end))

    if not found:
        return record, False

    tag, pos, end = rng.choice(found)
    value_start = pos + len(tag)
    value = record[value_start:end]
    if not value:
        return record, False

    insert_at = max(1, len(value)//2)
    injected = value[:insert_at] + "/" + tag_name + value[insert_at:]
    return record[:value_start] + injected + record[end:], True

def corrupt_record(record, rng):
    ctype = rng.choice(CORRUPTION_TYPES)

    if ctype == "truncate":
        if len(record) > 40:
            cut = rng.randint(20, min(80, len(record)-1))
            return record[:-cut], ctype

    if ctype == "drop_delimiter":
        idx = record.find("\\/")
        if idx >= 0:
            return record[:idx] + record[idx+2:], ctype

    if ctype == "bad_tag":
        tags = [t for t in KNOWN_TAGS if t in record]
        if tags:
            tag = rng.choice(tags)
            return record.replace(tag, tag[:2] + "?", 1), ctype

    if ctype == "bad_date":
        for tag in ("PUD","DOD","DOB"):
            pos = record.find(tag)
            if pos >= 0:
                value_start = pos + len(tag)
                if value_start + 7 <= len(record):
                    return record[:value_start] + "99XXX99" + record[value_start+7:], ctype

    if ctype == "insert_noise":
        pos = rng.randint(1, max(1, len(record)-1))
        return record[:pos] + "@@CORRUPT@@" + record[pos:], ctype

    return record + "@@CORRUPT@@", "insert_noise"

def divider_for(style, rng, index, pul):
    if style == "none":
        return ""

    if style in ("dashes", "filelink"):
        return "-" * 80

    if style == "imfsplitter":
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        filename = synthetic_filename(rng, index)
        route = "SQL" if pul in ("LIS","CDG","TIA") else "AS400"
        return (
            f"===== {ts} FILE={filename} MODE=PUL ACTION=MOVE INPUT=1 "
            f"PUL_OCCURRENCES=1 PUL={pul} ROUTE={route} "
            f"AS400OUT=False SQLOUT=True SQLMODE=SQL ====="
        )

    raise ValueError(f"Unknown divider style: {style}")

def build_file(count, seed=None, pul="mixed", divider="dashes", minimal=False,
               include_con=True, include_bcd=True, include_dlc=True,
               corrupt_percent=0.0, embed_tag="", embed_percent=0.0,
               test_markers=True):
    rng = random.Random(seed)
    chunks = []
    stats = {
        "corrupted": 0,
        "embedded": 0,
        "corruption_types": {},
    }

    for i in range(1, count+1):
        rpul = rng.choice(list(ROUTES)) if pul == "mixed" else pul

        record = make_record(
            rng,
            rpul,
            minimal=minimal,
            include_con=include_con,
            include_bcd=include_bcd,
            include_dlc=include_dlc,
            test_markers=test_markers,
        )

        if embed_tag and rng.random() * 100 < embed_percent:
            record, changed = embed_tag_inside_valid_value(record, rng, embed_tag)
            if changed:
                stats["embedded"] += 1

        if corrupt_percent > 0 and rng.random() * 100 < corrupt_percent:
            record, ctype = corrupt_record(record, rng)
            stats["corrupted"] += 1
            stats["corruption_types"][ctype] = stats["corruption_types"].get(ctype, 0) + 1

        div = divider_for(divider, rng, i, rpul)
        if div:
            chunks.append(div)

        chunks.append(record)

    if divider in ("dashes","filelink"):
        chunks.append("-" * 80)

    return "\n".join(chunks) + "\n", stats

def main():
    ap = argparse.ArgumentParser(description="Generate synthetic XMT IMF/RES test data.")

    ap.add_argument("-n","--count", type=int, default=DEFAULT_COUNT)
    ap.add_argument("-o","--output", default=DEFAULT_OUTPUT)
    ap.add_argument("--seed", type=int, default=DEFAULT_SEED)
    ap.add_argument("--pul", choices=["mixed","LIS","CDG","TIA"], default=DEFAULT_PUL)
    ap.add_argument("--divider", choices=["none","dashes","filelink","imfsplitter"], default=DEFAULT_DIVIDER)

    ap.add_argument("--minimal", action="store_true")
    ap.add_argument("--no-con", action="store_true")
    ap.add_argument("--no-bcd", action="store_true")
    ap.add_argument("--no-dlc", action="store_true")

    ap.add_argument(
        "--corrupt-percent",
        type=float,
        default=DEFAULT_CORRUPT_PERCENT,
        help="Randomly corrupt approximately this percentage of records (0-100)."
    )
    ap.add_argument(
        "--embed-tag",
        default=DEFAULT_EMBED_TAG,
        help="Embed a tag token such as ACT inside another valid tag value."
    )
    ap.add_argument(
        "--embed-percent",
        type=float,
        default=DEFAULT_EMBED_PERCENT,
        help="Percentage of records receiving the embedded tag (0-100)."
    )

    marker_group = ap.add_mutually_exclusive_group()
    marker_group.add_argument(
        "--test-markers",
        dest="test_markers",
        action="store_true",
        help="Use TESTNAME and TESTAD1/2/3 visible markers."
    )
    marker_group.add_argument(
        "--no-test-markers",
        dest="test_markers",
        action="store_false",
        help="Generate without TESTNAME and TESTAD1/2/3 visible markers."
    )
    ap.set_defaults(test_markers=DEFAULT_TEST_MARKERS)

    a = ap.parse_args()

    if not 1 <= a.count <= 100000:
        ap.error("--count must be between 1 and 100000")
    if not 0 <= a.corrupt_percent <= 100:
        ap.error("--corrupt-percent must be between 0 and 100")
    if not 0 <= a.embed_percent <= 100:
        ap.error("--embed-percent must be between 0 and 100")

    if a.embed_tag:
        a.embed_tag = a.embed_tag.upper()

    text, stats = build_file(
        a.count,
        seed=a.seed,
        pul=a.pul,
        divider=a.divider,
        minimal=a.minimal,
        include_con=not a.no_con,
        include_bcd=not a.no_bcd,
        include_dlc=not a.no_dlc,
        corrupt_percent=a.corrupt_percent,
        embed_tag=a.embed_tag,
        embed_percent=a.embed_percent,
        test_markers=a.test_markers,
    )

    Path(a.output).write_text(text, encoding="utf-8")

    print(f"Synthetic reservations written: {a.count}")
    print(f"Output file: {a.output}")
    print(f"PUL mode: {a.pul}")
    print(f"Divider style: {a.divider}")
    print(f"Seed: {a.seed if a.seed is not None else 'random'}")
    print(f"Test markers: {'ON' if a.test_markers else 'OFF'}")
    print(f"Corrupted records: {stats['corrupted']}")
    print(f"Embedded-tag records: {stats['embedded']}")

    if stats["corruption_types"]:
        print("Corruption breakdown:")
        for k in sorted(stats["corruption_types"]):
            print(f"  {k}: {stats['corruption_types'][k]}")

if __name__ == "__main__":
    main()
